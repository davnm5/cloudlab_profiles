from grafanalib.core import (
    Alert, AlertCondition, Dashboard, Graph,
    GreaterThan, OP_AND, OPS_FORMAT, Row, RTYPE_SUM, SECONDS_FORMAT,
    SHORT_FORMAT, single_y_axis, Target, TimeRange, YAxes, YAxis
)


               
dashboard = Dashboard(
    title="Test Monitor",
    rows=[
        Row(panels=[
          Graph(
              title="Available Memory",
            dataSource='Prometheus',
            targets=[
                Target(
                    expr='node_memory_MemAvailable_bytes{app="node-exporter"}',
                    legendFormat="node-{{instance}}",
                    refId='A',
                )
            ],
            yAxes=YAxes(
                YAxis(format=SHORT_FORMAT),
                YAxis(format=SHORT_FORMAT),
            ),
            ),
             Graph(
              title="Total Memory",
            dataSource='Prometheus',
            targets=[
                 Target(
                    expr='node_memory_MemFree_bytes{app="node-exporter"}',
                    legendFormat="node-{{instance}}",
                    refId='C',
                )
            ],
            yAxes=YAxes(
                YAxis(format=SHORT_FORMAT),
                YAxis(format=SHORT_FORMAT),
            ),
            )]),
        Row(panels=[
             Graph(
              title="Free Memory",
            dataSource='Prometheus',
            targets=[
                Target(
                    expr='node_memory_MemTotal_bytes{app="node-exporter"}',
                    legendFormat="node-{{instance}}",
                    refId='B',
                )
            ],
            yAxes=YAxes(
                YAxis(format=SHORT_FORMAT),
                YAxis(format=SHORT_FORMAT),
            ),
            ),

          Graph(
              title="CPU",
              dataSource='Prometheus',
              targets=[
                  Target(
                    expr='100 - (avg by (instance) (irate(node_cpu_seconds_total{mode="idle"}[10s])) * 100)',
                    legendFormat="node-{{instance}}",
                    refId='A',
                  ),
              ],
              yAxes=single_y_axis(format=SHORT_FORMAT),
          ),
        ]),
    ],
).auto_panel_ids()
## Instructions to deploy the monitor :

# first should add your url prometheus in grafana-config.yaml

<url>:30002/

# add node label monitor 
kubectl label nodes <node_name> nodelabel=monitor --overwrite=true

cd monitor/setup/
# start monitor
./monitor.sh start
# clean monitor (delete all in namespace monitoring)
./monitor.sh clean

* In the configmap dashboards-json a dashboard is defined that will appear loaded by default
* In grafana-config you can define more datasource, by default one is already defined that cannot be modified by UI

## Instructions to create dashboards format json with garfanalib:

git clone https://github.com/weaveworks/grafanalib
cd grafanalib
virtualenv .env
. ./.env/bin/activate
pip install -e .
generate-dashboard -o test.json test.dashboard.py

# the content of the test.json file can be added to grafana-dashboards.yaml for grafana to display a new loaded dashboard or it can be added via the UI.

## Instructions to download data from prometheus in format csv
cd monitor/setup
virtualenv .env
. ./.env/bin/activate
pip install -r requirements.txt
python3 query_csv.py <url_prometheus> <my_querys.txt>

* my_querys.txt is a file with a query by line
* All results of query is saved in file.csv
* In the query_csv.py the interval scrape is represented by the variable step
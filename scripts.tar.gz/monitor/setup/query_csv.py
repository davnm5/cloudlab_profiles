import csv
import requests
import time
import pandas as pd
import numpy as np
import sys
import os

now = int(time.time())
start = (now - 3600) # last hour
end = now
file_path = 'mem_usage.csv'
data = pd.DataFrame()
step = '2s' # fetch the data every 2 seconds
csv_file = open(file_path, "w")
writer = csv.writer(csv_file)
writer.writerow([u'timestamp', u'value',u'node',u'query'])

def fetch_data_range(prom_address,list_querys):
    for i in list_querys:
        try:
            response = requests.get('{0}/api/v1/query_range'.format(prom_address),
                        params={'query': i, 'start':start, 'end':end ,'step':step})

        except requests.exceptions.RequestException as e:
            print(e)
            return 
            
        if response.json()['status'] != "success":
            print("Error processing the request: " + response.json()['status'])
            print("The Error is: " + response.json()['error'])
            return

        results = response.json()['data']['result']

        if (results is None):
            print("the results[] came back empty!")
            return 0, 0, 0

        length = len(results)
        if length > 0:
            print("Saving result in file: {0}".format(file_path))

            for i in range(length):
                data = pd.DataFrame(data=np.array(results[i]['values']),dtype=float)
                data.columns = [u'timestamp', u'value']
                write_csv(results,i)
        else:
            print("the results[] has no entries!")
            return 0, 0, 0


def write_csv(results,i):
        for result in results[i]['values']:
            l = result
            l.append(results[i].get('metric').get('instance'))
            l.append(results[i].get('metric').get('__name__'))
            writer.writerow(l)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('Usage: {0} <url_prometheus> <file_querys>'.format(sys.argv[0]))
        sys.exit(1)
    if os.path.exists(sys.argv[2]):
        with open(sys.argv[2]) as f:
            list_querys = f.read().splitlines()
        fetch_data_range(sys.argv[1],list_querys)
        csv_file.close()
    else:
        print("file not exist") 

  
#!/bin/bash

if [ "$#" != 1 ] | [ "$1" != "start" ] && [ "$1" != "clean" ]; then
    echo "Illegal parameters"
    exit 1
fi

if [ "$1" == "start" ];then
    echo "STARTING MONITOR..."
    kubectl apply -f ../prometheus/
    kubectl apply -f ../grafana/
else
    echo "CLEANING MONITOR..."
    kubectl delete all --all -n monitoring
fi
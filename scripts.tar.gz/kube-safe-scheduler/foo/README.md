# Foo Agent: A template for expanding on the scheduler extender

The Foo agent scheduler extender is provided as a template to ease the addition of new agents.


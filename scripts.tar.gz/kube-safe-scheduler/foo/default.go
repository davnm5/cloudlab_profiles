package foo

/**
 * Names of predicates and priority functions
 */
const (
	// PredicateSafeOverloadName : name of predicate
	PredicateFooName = "foo"
	// PriorityFooName : name of priority function
	PriorityFooName = "foo"
)

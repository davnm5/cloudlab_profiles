// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

	   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	cell-rft.c
	Abstract:	Implements an Cell Selector xapp with partial replication properties
				A cell is selected based on signal stregth and a threshold of max UE supported in that cell

				Compilation flags:
					- use -DRFT to enable RFT in compilation time
					- to disable replication (i.e. RFT) remove the -DRFT flag

				Command line options and parameters:
					- Run program passing "-" as argument

	Date:		29 May 2020
	Author:		Alexandre Huff
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <pthread.h>

#include <rmr/rmr.h>

#include <rft/rft.h>
#include <rft/logger.h>

#include "exp.h"

// #define RFT

typedef struct cell_data {
	int from_cell;
	int to_cell;
} cell_data_t;

void	*mrc;					// msg router context
int		max_attempts = 1;		// max reply attempts using rmr_rts_msg

/* ===== Experiment variables ===== */
long	max_ue = 50;			// max UE admitted in a cell
int		local_cells[3];			// counter of the number of UE connected of the Primary server (its me)
int		replica_cells[3];		// counter of the number of UE connected of the Backup server (its the replica of another server)
pthread_mutex_t local_state_lock = PTHREAD_MUTEX_INITIALIZER;	// local_cells
pthread_mutex_t backup_state_lock = PTHREAD_MUTEX_INITIALIZER;	// replica_cells

/* ===== stats variables ===== */
#if LOGGER_LEVEL >= LOGGER_INFO
	pthread_mutex_t count_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t reply_lock = PTHREAD_MUTEX_INITIALIZER;
	long	count = 0;			// only for reporting purposes
	long	last_count = 0;		// only for reporting purposes
#endif
long	replied = 0;
long	retries = 0;
long	errors = 0;
long	timeouts = 0;
long	sfailed = 0;			// send/reply failed
/* ===== stats variables up to here ===== */


// function that will be called by the rft library
void apply_rstate( const int cmd, const char *context, const char *key, const unsigned char *data, const size_t dlen ) {
	cell_data_t *cmd_data = (cell_data_t *) data;

	if( cmd == CHG_HANDOVER_STATE ) {
		pthread_mutex_lock( &backup_state_lock );

		// decrementing by 1 only if from_cell > 0
		replica_cells[cmd_data->from_cell - 1] -= ( replica_cells[cmd_data->from_cell - 1] > 0 );
		// incrementing by 1 only if to_cell < max UEs (e.g. 50)
		replica_cells[cmd_data->to_cell - 1] += ( replica_cells[cmd_data->to_cell - 1] < max_ue );

		#if LOGGER_LEVEL >= LOGGER_INFO
			assert( replica_cells[cmd_data->from_cell - 1] >= 0 );
			assert( replica_cells[cmd_data->to_cell - 1] <= max_ue );
		#endif

		pthread_mutex_unlock( &backup_state_lock );

	} else {
		logger_error( "unknown apply_rstate command %d", cmd );
	}

}


/*
	Computes the elapsed time between ts1 and ts2.
	Returns miliseconds.
*/
static inline long elapsed( struct timespec* start_ts, struct timespec* end_ts ) {
	long long start;
	long long end;

	start = ( start_ts->tv_sec * 1000000000) + start_ts->tv_nsec;
	end = ( end_ts->tv_sec * 1000000000) + end_ts->tv_nsec;

	return (long) (end - start) / 1000000;			// to milliseconds
}


/*
	This thread works as the listener of all incoming messages
	Its purpose is to unburden the RMR's receiver ring queue, and thus
	decreasing the number of dropped messages
*/
void *listener( ) {
	int			i;
	int			repeat;				// retries counter
	rmr_mbuf_t	*msg = NULL;

	#if LOGGER_LEVEL >= LOGGER_WARN
		unsigned char target[RMR_MAX_SRC];
	#endif

	// ===== Experiment =====
	hand_request_t	*request;			// payload received in the experiment
	hand_reply_t	*reply;				// payload sent back to the WG
	#ifdef RFT
    	cell_data_t 	cmd_data;
    #endif
	int				max_signal;
	int				cell_idx;
	long			msg_seq;
	int				found;

	while ( 1 ) { // listener for all incomming messages
		msg = rmr_rcv_msg( mrc, msg );

		if ( msg && msg->state == RMR_OK ) {

			switch ( msg->mtype ) {

				case APPEND_ENTRIES_REQ:
				case APPEND_ENTRIES_REPLY:
				case VOTE_REQ:
				case VOTE_REPLY:
				case MEMBERSHIP_REQ:
				case REPLICATION_REQ:
				case REPLICATION_REPLY:
					logger_trace( "%-*s type: %d, len: %3d, mrc: %p, msg: %p", LOGGER_PADDING, "receiving message", msg->mtype, msg->len, mrc, msg );

					#ifdef RFT
						rft_enqueue_msg( msg );
					#endif
					break;

				case HAND_REQUEST0:
				case HAND_REQUEST1:
				case HAND_REQUEST2:
				case HAND_REQUEST3:
				case HAND_REQUEST4:
					request = (hand_request_t *) msg->payload;
					msg_seq = request->seq;

					found = 3;
					while( found ) {
						max_signal = request->signals[0];
						cell_idx = 0;
						for( i = 1; i < 3; i++ ) {
							if( request->signals[i] > max_signal ) {
								cell_idx = i;
								max_signal = request->signals[i];
							}
						}

						if( cell_idx + 1 == request->src_cell ) {	// the best is the same
							found = 0;
							break;
						}

						pthread_mutex_lock( &local_state_lock );
						if( local_cells[cell_idx] < max_ue ) {
							pthread_mutex_unlock( &local_state_lock );
							break;
						}
						pthread_mutex_unlock( &local_state_lock );

						request->signals[cell_idx] = -1;	// reset it to not be the max again
						found--;
					}

					// if( found ) {	// if there is a cell to handover
					if( found && ( local_cells[request->src_cell - 1] > 0 ) && ( local_cells[cell_idx] < max_ue ) ) {	// if there is a cell to handover
						#ifdef RFT
						    cmd_data.from_cell = request->src_cell;
						    cmd_data.to_cell = cell_idx + 1;
						
							rft_replicate( CHG_HANDOVER_STATE, "CELL1", "key1", (unsigned char *) &cmd_data, sizeof( cell_data_t ) );
						#endif

						pthread_mutex_lock( &local_state_lock );
						// local_cells[request->src_cell - 1]--;
						// local_cells[cell_idx]++;
						// decrementing by 1 only if from_cell > 0
						local_cells[request->src_cell - 1] -= ( local_cells[request->src_cell - 1] > 0 );
						// incrementing by 1 only if to_cell < max UEs (e.g. 50)
						local_cells[cell_idx] += ( local_cells[cell_idx] < max_ue );

						#if LOGGER_LEVEL >= LOGGER_INFO
							assert( local_cells[request->src_cell - 1] >= 0 );
							assert( local_cells[request->src_cell - 1] <= max_ue );
						#endif

						pthread_mutex_unlock( &local_state_lock );

						reply = (hand_reply_t *) msg->payload;
						reply->seq = msg_seq;
						reply->dst_cell = cell_idx + 1;

						msg->mtype = HAND_ACK;

					} else {
						reply = (hand_reply_t *) msg->payload;
						reply->seq = msg_seq;
						reply->dst_cell = -1;

						msg->mtype = HAND_NACK;
					}

					#if LOGGER_LEVEL >= LOGGER_DEBUG
						logger_debug( "msg: %ld, cell: [ %2d, %2d, %2d ]", reply->seq + 1, local_cells[0], local_cells[1], local_cells[2] );
					#endif

					/*
						From here is the logic to reply messages to the WG
					*/
					repeat = max_attempts;
					do {
						msg = rmr_rts_msg( mrc, msg );

						repeat--;
					} while(repeat && msg && ( msg->state == RMR_ERR_SENDFAILED || msg->state == RMR_ERR_RETRY ) );

					if( msg != NULL ) {
						switch( msg->state ) {
							case RMR_OK:
								LOCK( &reply_lock );
								replied++;
								UNLOCK( &reply_lock );
								break;

							case RMR_ERR_SENDFAILED:
								sfailed++;
								#if LOGGER_LEVEL >= LOGGER_WARN
									logger_error( "send failed, mtype: %d, state: %d, strerr: %s\n",
												  msg->mtype, msg->state, strerror( errno ) );
								#endif
								break;

							case RMR_ERR_RETRY:
								retries++;
								#if LOGGER_LEVEL >= LOGGER_WARN
									if( max_attempts ) {		// only show retries by using rts loop (without loop generates a lot of retry messages)
										rmr_get_src( msg, target );
										strtok( (char *) target, ":" );	// replacing ':' to '\0'
										logger_warn( "message dropped with state RMR_ERR_RETRY, seq: %ld, target: %s, mtype: %d",
													reply->seq + 1, (char *) target, msg->mtype );
									}
								#endif
								break;

							// case RMR_ERR_TIMEOUT:
							default:
								logger_error( "send error, state: %d, strerr: %s", msg->state, strerror( errno ) );
								errors++;
						}

					} else {
						logger_error( " extreme failure, unable to send message using RMR");
						exit( 1 );
					}

					LOCK( &count_lock );
					#if LOGGER_LEVEL >= LOGGER_INFO
						count++;
					#endif
					UNLOCK( &count_lock );

					break;

				default:
					logger_warn( "unrecognized message type: %d", msg->mtype);
				break;
			}

		} else {
			logger_error( "unable to receive message, type :%d, state: %d, errno: %d", msg->mtype, msg->state, errno );
		}
	}
}


int main( int argc, char **argv ) {
	int 		ai = 1;					// argument index
	long		timeout;				// timeout to wait RMR configure routing table
	char		*listen_port = NULL;	// RMR port to exchange messages
	int			max_retries = 1;		// RMR max retries before giving up and returning to the xapp with RMR_ERR_RETRY
	char		wbuf[256];
	int			i;

	pthread_t	*threads;
	int			nthreads = 1;			// number of receiver threads
	int			ret;					// general return code

	while( ai < argc ) {
		if( *argv[ai] == '-' ) {
			switch( argv[ai][1] ) {
				case 'p':
					ai++;
					listen_port = argv[ai];
					break;

				case 'r':
					ai++;
					max_retries = atoi( argv[ai] );
					break;

				case 'l':
					ai++;
					max_attempts = atoi( argv[ai] );
					break;

				case 'm':
					ai++;
					max_ue = atoi( argv[ai] );
					break;
				
				case 'n':
					ai++;
					nthreads = atoi( argv[ai] );
					if( nthreads < 1 )
						nthreads = 1;
					break;

				default:
					fprintf( stderr, "[FAIL] unrecognized option: %s\n", argv[ai] );
					fprintf( stderr, "\nUsage: %s [-p port] [-r max_rmr_retries] [-l max attempts]"
									 " [-m max UEs per cell] [-n num_threads]\n", argv[0] );
					exit( 1 );
			}

			ai++;
		} else {
			break;		// not an option, leave with a1 @ first positional parm
		}
	}

	if( ! listen_port )
		listen_port = "4560";

	srand( time( NULL ) );

	if( getenv( "RMR_RTG_SVC" ) == NULL ) {		// setting random listener port
		snprintf( wbuf, sizeof(wbuf), "%d", 19000 + ( rand() % 1000 ) );
		setenv( "RMR_RTG_SVC", wbuf, 1 );		// set one that won't collide with the default port if running on same host
	}

	threads = (pthread_t *) malloc( nthreads * sizeof( pthread_t ) );
	if( threads == NULL ) {
		logger_error( "unable to allocate memory to initilize threads" );
		exit( 1 );
	}

	mrc = rmr_init( listen_port, RMR_MAX_RCV_BYTES, RMRFL_NONE );	// start your engines!
	if( mrc == NULL ) {
		logger_error( "unable to initialize RMR" );
		exit( 1 );
	}
	rmr_set_fack( mrc );

	if( rmr_set_stimeout( mrc, max_retries ) != RMR_OK )
		logger_error( "unable to set rmr max retries" );

	timeout = time( NULL ) + 20;
	while( ! rmr_ready( mrc ) ) {								// wait for RMR configuring the route table
		logger_info( "waiting for RMR to show ready" );
		sleep( 1 );

		if( time( NULL ) > timeout ) {
			logger_error( "giving up" );
			exit( 1 );
		}
	}

	logger_info( "listening on port %s, threads: %d, max_attempts: %d, max UEs/cell: %d",
				  listen_port, nthreads, max_attempts, max_ue );

	#ifdef RFT
		rft_init( mrc, listen_port, 1024*1024, apply_rstate );
	#endif

	// initializing cell counters to half of the max
	for( i = 0; i < 3; i++ ) {
		local_cells[i] = max_ue / 2;
		replica_cells[i] = max_ue / 2;
	}

	logger_info( "initial cell: [ %2d, %2d, %2d ]", local_cells[0], local_cells[1], local_cells[2] );

	/* ===== Creating threads ===== */
	for( i = 0; i < nthreads; i++ ) {
		ret = pthread_create( &threads[i], NULL, listener, NULL );
		if( ret != 0 ) {
			logger_error( "error on creating thread: %s\n", strerror( ret ) );
			exit( 1 );
		}
	}

	/* ===== Stats ===== */
	#if LOGGER_LEVEL >= LOGGER_INFO
		while( 1 ) {
			sleep( 5 );
			if( last_count != count ) {
				logger_info( "========== Requests: %ld\tReplied: %ld\tRetries: %ld\tSend Failed: %ld\t\tErrors: %ld ==========",
							count, replied, retries, sfailed, errors );
				logger_info( "========== local_cells: [ %3d, %3d, %3d ]\treplica_cells: [ %3d, %3d, %3d ] ==========",
							local_cells[0], local_cells[1], local_cells[2], replica_cells[0], replica_cells[1], replica_cells[2] );

				last_count = count;
			}
		}
	#endif

	// unreachable with LOGGER_INFO
	for( i = 0; i < nthreads; i++ ) {
		pthread_join( threads[i], NULL );
	}

	free( threads );

	return 0;
}

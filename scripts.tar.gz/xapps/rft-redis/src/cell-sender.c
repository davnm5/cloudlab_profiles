// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

	   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	cell-sender.c
	Abstract:	Measures the threshold of incomming messages for xapp instances with partial replication properties
				Also measures latency and throughput of sent messages

				Command line options and parameters:
					- Run program passing "-" as argument

	Date:		25 February 2020
	Author:		Alexandre Huff
*/

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <time.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>

#include <rmr/rmr.h>

#include <gsl/gsl_sort_long.h>
#include <gsl/gsl_statistics_long.h>

#include "exp.h"


typedef struct data {
	int replied;	// if the WG received that message reply
	// int signal1;	// signal strengh of cell1
	// int signal2;	// signal strengh of cell2
	// int signal3;	// signal strengh of cell3
	int from_cell; 	// stores which cell that UE is currently connected to at the request
	int to_cell;	// stores the reply of which cell that UE needs to connect (handover)
	int mtype;		// stores each message returned type (ack or nack)
	struct timespec out_ts;	// WG message send timestamp
	struct timespec in_ts;	// WG message reply timestamp
	long rtt;				// round trip time of this message ( to avoid recalculate more than once on report )
	long msg_seq;	// message sequence number
	unsigned char xapp[RMR_MAX_SRC];	// stores which xApp replied this message
} data_t;


// ---------------------------------------------------------------------------
/*
	Compute the elapsed time between ts1 and ts2.
	Author:		E. Scott Daniels
*/
static inline long elapsed( struct timespec* start_ts, struct timespec* end_ts ) {
	long long start;
	long long end;
	long bin;

	start = ( start_ts->tv_sec * 1000000000) + start_ts->tv_nsec;
	end = ( end_ts->tv_sec * 1000000000) + end_ts->tv_nsec;

	// bin = (end - start) / 1000000;			// msec
	bin = (end - start) / 1000;					// mu-sec

	return bin;
}

/*
	Compares two long pointers for ascending sorting
*/
static inline int cmp_long( const void *v1, const void *v2 ) {
	return *((long *) v1) - *((long *) v2);
}

int main( int argc, char** argv ) {
	int		ai = 1;						// arg index
	long	i;
	long	j;
	long	msgs = 10;					// number of messages to be transmitted
	int		listen_port = 0;			// the port we open for "backhaul" connections
	int		rand_port = 0;				// sets and causes us to generate a random listen port
	int		verbose = 0;				// defines if rtt timestamp records will be saved in a file (verbose)
	char	wbuf[256];					// short writing buffer
	int		repeat;						// used to iterate over max_retries on sending msg to backup route
	int 	max_timeout = 2000;			// max timeout for waiting a reply message
	int		max_retries = 1;			// number of RMR retries before giving up sending message (RMR_ERR_RETRY)
	long	max_chunk = 1;				// maximum number of messages sent at each interval (chunk)
	long	ccount = 0;					// message chunk counter
	int		mtype = HAND_REQUEST0;		// default RMR message type
	long	num2send;					// number of messages to be transmitted
	unsigned long interval = 0;			// waiting time (nsec) before send the next message

	void	*mrc = NULL;				// msg router context

	struct	timespec begin_ts;			// time we begin to send messages
	struct	timespec end_ts;			// time we sent all messages
	long	replies = 0;				// total of replied messages
	long	retries = 0;				// WG rmr retries
	long	lost = 0;					// lost messages, mainly due to RMR_ERR_RETRY on the xApp rmr_rts_msg()
	data_t	*logs;						// array to store information of each message
	/*
		number of targets in routing table that will receive the same copy of message
		this is "the ; rule in rt" (not round-robin)
	*/
	int		targets = 1;
	/*
		RMR's ring buffer size (message queue), we use it to avoid RMR drop messages due to get the ring buffer full
		Look at mring on uta_ctx_t in RMR "ctx->mring = uta_mk_ring( 4096 );"
	*/
	int		ring_buffer = 4096;
	/*
		defines if the workload generator should estimate the number of messages in the message queue at the receiver
	*/
	int		estimate = 0;

	struct		epoll_event events[1];		// list of events to give to epoll
	struct		epoll_event epe;			// event definition for event to listen to
	int			ep_fd = -1;					// epoll's file descriptor (given to epoll_wait)
	int			rcv_fd;						// file that SI95 tickles -- give this to epoll to listen on
	long		count = 0;					// sender's message counter
	rmr_mbuf_t	*sbuf;						// send message buffer
	rmr_mbuf_t	*rbuf;						// receive message buffer
	hand_request_t	*request;				// the sender payload in a message
	hand_reply_t	*reply;					// the receiver payload in a message
	int			nready;						// number of events ready to receive
	struct		timespec nanots = {0, 0 };	// timespec for nanosleep

	long	last_replied;					// stores the last replied message index
	float	running_time;
	float	rate_sec;
	float	max_latency;
	float	min_latency;
	double	avg_latency;
	double	stddev_latency;

	long	*rcv_rtts;						// rtt array used for statistics reports
	double	p95;							// the 95th percentile rtt
	double	p99;							// the 99th percentile rtt

	int			ret;						// function return buffer

	FILE		*fp;
	char		*filename = NULL;
	struct stat sb;							// fstat buffer

	// unsigned long h;						// calculated hash index
	// replies_t	*hashtable[HASHTABLE_SIZE] = { NULL };		// stores pointers of the last change for each xApp

	// ---- simple arg parsing ------
	while( ai < argc ) {
		if( *argv[ai] == '-' ) {
			switch( argv[ai][1] ) {
				case 'p':
					ai++;
					listen_port = atoi( argv[ai] );
					break;

				case 'n':					// num msgs to send
					ai++;
					msgs = atol( argv[ai] );
					break;

				case 'm':
					ai++;
					mtype = atoi( argv[ai] );
					break;

				case 'i':					// interval to send in mu-sec
					ai++;
					interval = (unsigned int) strtoul( argv[ai], NULL, 10 );
					break;

				case 't':					// max waiting timeout for a reply in ms
					ai++;
					max_timeout = atoi( argv[ai] );
					break;

				case 'r':
					ai++;
					max_retries = atoi( argv[ai] );
					if ( max_retries < 0 )
						max_retries = 0;
					break;

				case 'g':
					ai++;
					targets = atoi( argv[ai] );
					break;

				case 'o':
					ai++;
					filename = argv[ai];
					break;

				case 'c':
					ai++;
					max_chunk = strtol( argv[ai], NULL, 10 );
					if( max_chunk < 1 )
						max_chunk = 1;
					break;

				case 'l':					// generate random listen port
					rand_port = 1;
					break;

				case 'v':					// summarizes only RTT timestamps for MSG Reply changes in a file
					verbose = 1;
					break;

				case 'e':
					estimate = 1;
					break;

				default:
					fprintf( stderr, "\nUsage: %s [-p listen port] [-n send msgs] [-m mtype] [-i interval nsec] [-c chunk]"
									 " [-t reply timeout ms] [-r max attempts] [-g rt targets]"
									 " [-o output filename] [-v] [-l] [-e]\n", argv[0] );
					fprintf( stderr, "\t\tOptions:\n" );
					fprintf( stderr, "\t\t[-c] sends at most n messages (chunk) at each interval (-i is required)\n" );
					fprintf( stderr, "\t\t[-e] estimates the number of messages in the recipient's message queue\n" );
					fprintf( stderr, "\t\t     and pauses sending messages while it is full\n" );
					fprintf( stderr, "\t\t[-v] saves all RTT records in the output file (-o is required)\n" );
					fprintf( stderr, "\t\t[-l] generates and uses a random listen port (-p has precedence)\n" );
					fprintf( stderr, "\t\t[-g] waits replies for the specified number of targets (each receives the same msg copy - multicast)\n\n" );
					exit( 1 );
			}

			ai++;
		} else {
			break;		// not an option, leave with a1 @ first positional parm
		}
	}

	logs = (data_t *) malloc( msgs * targets * sizeof(data_t) );
	if( logs == NULL ) {
		fprintf( stderr, "[FAIL] unable to allocate memory for logs array\n" );
		exit( 1 );
	}

	srand( time( NULL ) );

	if( getenv( "RMR_RTG_SVC" ) == NULL ) {		// setting random listener port
		snprintf( wbuf, sizeof(wbuf), "%d", 19000 + ( rand() % 1000 ) );
		setenv( "RMR_RTG_SVC", wbuf, 1 );		// set one that won't collide with the default port if running on same host
	}

	if( listen_port ) {
		snprintf( wbuf, sizeof( wbuf ), "%d", listen_port );

	} else if( rand_port ) {
		snprintf( wbuf, sizeof(wbuf), "%d", 43000 + ( rand() % 1000) );			// random listen port

	} else {
		snprintf( wbuf, sizeof( wbuf ), "4570");		// default port
	}

	if( interval == 0 )
		max_chunk = 0;

	fprintf( stderr, "[INFO] listening port: %s; sending %ld messages; type %d; interval %lu nanosec; chunk %ld msg/interval\n",
			wbuf, msgs, mtype, interval, max_chunk );

	if( ( mrc = rmr_init( wbuf, RMR_MAX_RCV_BYTES, RMRFL_NONE )) == NULL ) {
		fprintf( stderr, "[FAIL] unable to initialize RMR\n" );
		exit( 1 );
	}
	rmr_set_fack( mrc );

	if( rmr_set_stimeout( mrc, max_retries ) != RMR_OK )
		fprintf ( stderr, "[WARN] unable to set rmr max retries\n");

	rcv_fd = rmr_get_rcvfd( mrc );
	if( rcv_fd < 0 ) {
		fprintf( stderr, "[FAIL] unable to set up polling fd\n" );
		exit( 1 );
	}
	if( (ep_fd = epoll_create1( 0 )) < 0 ) {
		fprintf( stderr, "[FAIL] unable to create epoll fd: %d\n", errno );
		exit( 1 );
	}
	epe.events = EPOLLIN;
	epe.data.fd = rcv_fd;

	if( epoll_ctl( ep_fd, EPOLL_CTL_ADD, rcv_fd, &epe ) != 0 ) {
		fprintf( stderr, "[FAIL] epoll_ctl status not 0 : %s\n", strerror( errno ) );
		exit( 1 );
	}

	fprintf( stderr, "[INFO] RMR initialized\n" );

	while( ! rmr_ready( mrc ) ) {
		sleep( 1 );
	}

	num2send = msgs;				// needs to be after warmup, since warmup has its own number of messages

	fprintf( stderr, "[INFO] sending messages...\n" );

	/***************** SENDER *****************/

	sbuf = rmr_alloc_msg( mrc, sizeof( hand_request_t ) );		// send buffer
	rbuf = rmr_alloc_msg( mrc, sizeof( hand_reply_t ) );		// receive buffer

	timespec_add_ns( nanots, interval );

	clock_gettime( CLOCK_REALTIME, &begin_ts );
	for( count = 0; count < num2send; count++, ccount++ ) {		// we send n messages
		if( !sbuf ) {
			fprintf( stderr, "[FAIL] sbuf is nil?\n" );
			exit( 1 );
		}

		request = (hand_request_t *) sbuf->payload;
		request->seq = count;		// doing an optimization to avoid decrement 1 at in the receiver thread
		request->signals[0] = rand() % 101;			// signal from 0 to 100
		request->signals[1] = rand() % 101;
		request->signals[2] = rand() % 101;
		request->src_cell = 1 + ( rand() % 3 );		// we are using 3 cells in this experiment (ranging from 1 to 3)

		sbuf->mtype = mtype;
		sbuf->sub_id = -1;
		sbuf->len = sizeof( *request );
		sbuf->state = 0;

		logs[count].replied = 0;	// set message as not replied yet
		logs[count].msg_seq = count + 1;
		logs[count].from_cell = request->src_cell;

		repeat = max_retries;
		do {
			clock_gettime( CLOCK_REALTIME, &logs[count].out_ts );
			sbuf = rmr_send_msg( mrc, sbuf );

			repeat--;
		} while( repeat && sbuf && ( sbuf->state == RMR_ERR_SENDFAILED || sbuf->state == RMR_ERR_RETRY ) );

		switch( sbuf->state ) {
			case RMR_OK:
				break;

			case RMR_ERR_RETRY:
			case RMR_ERR_TIMEOUT:
				retries++;
				break;

			default:
				fprintf( stderr, "[ERR] send failed, mtype: %d, state: %d, strerr: %s\n", sbuf->mtype, sbuf->state, strerror( errno ) );
				exit( 1 );
		}
		ring_buffer -= estimate;	// guessing the RMR's ring buffer size of the xApp

		/***************** RECEIVER *****************/
		if( ring_buffer > 0 ) {
			nready = epoll_wait( ep_fd, events, 1, 0 );				// if something ready to receive (non-blocking check)
		} else {
			nready = epoll_wait( ep_fd, events, 1, max_timeout );	// in case xApp receiver buffer is full we stop (block) for a while
			if( nready == 0 )	// means that most likely the xApp has failed, so, we no longer will send messages
				break;
		}

		while( nready > 0 ) {
			if( events[0].data.fd == rcv_fd ) {						// we only are waiting on 1 thing, so [0] is ok

				rbuf = rmr_rcv_msg( mrc, rbuf );
				if( rbuf && rbuf->state == RMR_OK ) {
					reply = (hand_reply_t *) rbuf->payload;

					clock_gettime( CLOCK_REALTIME, &logs[reply->seq].in_ts );	// time stamp of last message (and in_ts) received to compute rate

					logs[reply->seq].replied = 1;
					logs[reply->seq].to_cell = reply->dst_cell;

					// validating if mtype is ACK_HAND or NACK_HAND in report
					logs[reply->seq].mtype = rbuf->mtype;

					rmr_get_src( rbuf, logs[reply->seq].xapp );

					replies++;
				} else {
					fprintf( stderr, "\x1b[31m[ERR]\x1b[0m unexpected error on rmr_rv_msg\n" );
					exit( 1 );
					break;
				}

				ring_buffer += estimate;	// guessing the RMR's ring buffer size of the xApp
			}
			nready = epoll_wait( ep_fd, events, 1, 0 );		// if something ready to receive (non-blocking check)
		}

		/***************** SENDER INTERVAL *****************/
		if ( interval && ccount == max_chunk ) {
			nanosleep( &nanots, NULL );
			ccount = 0;
		}
	}

	/***************** RECEIVER AFTER ALL MESSAGES WERE SENT *****************/
	/* we want to receive n messages (each target received the same msg copy -g) */
	num2send *= targets;
	while( replies < num2send ) {	// unfortunatelly we have to duplicate the receiver code
		if( (nready = epoll_wait( ep_fd, events, 1, max_timeout )) > 0 ) {	// waits up to max_timeout to receive the last msg
			if( events[0].data.fd == rcv_fd ) {								// we only are waiting on 1 thing, so [0] is ok

				rbuf = rmr_rcv_msg( mrc, rbuf );
				if( rbuf && rbuf->state == RMR_OK ) {
					reply = (hand_reply_t *) rbuf->payload;

					clock_gettime( CLOCK_REALTIME, &logs[reply->seq].in_ts );	// timestamp of last message (and in_ts) received to compute rate

					logs[reply->seq].replied = 1;
					logs[reply->seq].to_cell = reply->dst_cell;

					// validating if mtype is ACK_HAND or NACK_HAND in report
					logs[reply->seq].mtype = rbuf->mtype;

					rmr_get_src( rbuf, logs[reply->seq].xapp );

					replies++;
				} else {
					fprintf( stderr, "\x1b[31m[ERR]\x1b[0m unexpected error on rmr_rv_msg\n" );
					exit( 1 );
					break;
				}
			}
		} else {
			break;		// nothing received within max timeout, giving up
		}
	}

	rmr_close( mrc );

	/***************** REPORT *****************/
	fprintf( stderr, "[INFO] generating report...\n" );

	if( replies ) {
		rcv_rtts = (long *) malloc( replies * sizeof(long) );
		if( !rcv_rtts ) {
			fprintf( stderr, "[FAIL] unable to allocate memory for RTT stats\n" );
			exit( 1 );
		}

		for( i = 0, j = 0; i < num2send; i++ ) {
			if( logs[i].replied ) {
				logs[i].rtt = elapsed( &logs[i].out_ts, &logs[i].in_ts );
				rcv_rtts[j++] = logs[i].rtt;

				/* validating returned handover message type here, this avoid an if|switch in the receiver code */
				if( logs[i].mtype != HAND_ACK && logs[i].mtype != HAND_NACK ) {
					fprintf( stderr, "\x1b[31m[ERR]\x1b[0m unexpected handover message, seq: %ld, type: %d\n", logs[i].msg_seq, logs[i].mtype );
					exit( 1 );
				}

				last_replied = i;
			}
		}

		end_ts = logs[last_replied].in_ts;		// getting the timestamp of the last replied message
		running_time = elapsed( &begin_ts, &end_ts ) / 1000000.0;				// mu-sec to sec

		rate_sec = ( replies ) / running_time;

		avg_latency = gsl_stats_long_mean( rcv_rtts, 1, replies ) / 1000.0;		// mu-sec to ms;
		stddev_latency = gsl_stats_long_sd( rcv_rtts, 1, replies ) / 1000.0;

		max_latency = gsl_stats_long_max( rcv_rtts, 1, replies ) / 1000.0;		// mu-sec to ms
		min_latency = gsl_stats_long_min( rcv_rtts, 1, replies ) / 1000.0;

		qsort( rcv_rtts, replies, sizeof(long), cmp_long );				//	sorting the rtt array

		p95 = gsl_stats_long_quantile_from_sorted_data( rcv_rtts, 1, replies, 0.95 ) / 1000.0;	// 95th percentile (mu-sec to ms)
		p99 = gsl_stats_long_quantile_from_sorted_data( rcv_rtts, 1, replies, 0.99 ) / 1000.0;	// 99th percentile (mu-sec to ms)

	} else {
		clock_gettime( CLOCK_REALTIME, &end_ts );	// get time in case no reply, just for report
		running_time = elapsed( &begin_ts, &end_ts ) / 1000000.0;		// mu-sec to sec

		rate_sec = stddev_latency = 0.0;
		max_latency = min_latency = 0.0;
		p95 = p99 = 0.0;
	}

	lost = num2send - replies - retries;

	fprintf( stderr, "\n[INFO]\tRequests: %-10ld\tReplies: %-10ld\tRetries (WG): %ld\t\t\tDrops (xApps): %ld\n"
					 "\n\tMax: %.3f ms\t\tMin: %.3f ms\t\t95th: %.3lf ms  \t\t99th: %.3lf ms\n"
					 "\n\tRate: %.2f msg/sec\tAVG: %.3lf ms\t\tStd-dev: %.3lf ms\t\tElapsed: %.3f sec\n"
					 "\n\tSend Interval: %lu nsec\tMSG/Interval: %ld\n\n",
					 num2send, replies, retries, lost,
					 max_latency, min_latency, p95, p99,
					 rate_sec, avg_latency, stddev_latency, running_time,
					 interval, max_chunk );

	if( filename ) {
		fprintf( stderr, "[INFO] writing results into file %s\n", filename );

		if( verbose ) {
			fp = fopen( filename, "w+" );	// overwrite file
		} else {
			fp = fopen( filename, "a+" );	// append file
		}
		if( fp == NULL ) {
			fprintf( stderr, "[FAIL] unable to create/open file %s, reason: %s\n", filename, strerror( errno ) );
			exit( 1 );
		}

		ret = fstat( fileno(fp), &sb );
		if( ( ret == -1 ) || ( !S_ISREG( sb.st_mode ) ) ) {
			fprintf( stderr, "[FAIL] unable getting stat of the regular file %s, reason: %s\n", filename, strerror( errno ) );
			fclose( fp );
			exit( 1 );
		}

		ret = fgetc( fp );
		if( ret == EOF ) {	// if there is no char in the file, we write a header
			fprintf( fp, "# Requests | Replies | Retries (WG) | Drops (xApps) |"
						 " Send Interval (nanosec) | Chunk (msg/interval) | Rate (msg/sec) | Latency (ms) |"
						 " Std-dev (ms) | Max (ms) | Min (ms) | 95%% (ms) |"
						 " 99%% (ms) | Elapsed (sec)\n" );
		}

		fprintf( fp, "%ld | %ld | %ld | %ld | "
					 "%lu | %ld | %.2f | %.3lf | "
					 "%.3lf | %.3f | %.3f | %.3lf | "
					 "%.3lf | %.3f\n",
					 num2send, replies, retries, lost,
					 interval, max_chunk, rate_sec, avg_latency,
					 stddev_latency, max_latency, min_latency, p95,
					 p99, running_time );

		if( verbose ) {	// write message tracking if desired
			fprintf( fp, "# MSG Sequence Number | MSG Latency (ms) | Elapsed Time (ms) | From Cell | To Cell | MSG Reply | SRC xApp\n" );
			for( i = 0; i < num2send; i++ ) {
				if( logs[i].replied ) {
					strtok( (char *) logs[i].xapp, ":" );	// taking off :port from the xapp string

					// mu-sec to ms
					fprintf( fp, "%ld | %.3f | %.3f | %d | %d | %s | %s\n", logs[i].msg_seq, logs[i].rtt / 1000.0,
							elapsed( &begin_ts, &logs[i].in_ts ) / 1000.0,
							logs[i].from_cell, logs[i].to_cell,
							logs[i].mtype == HAND_ACK ? "ACK" : "NACK", logs[i].xapp );
				}
			}
		}

		fclose( fp );
	}

	if( rcv_rtts != NULL )
		free( rcv_rtts );

	free( logs );

	return 0;
}

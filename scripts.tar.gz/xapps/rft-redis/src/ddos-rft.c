// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	ddos-rft.c
	Abstract:	Implements a multi-threaded xapp with global replication properties
				This file only implements state replication using the RFT library

				Compilation flags:
					- use -DRFT to enable RFT in compilation time
					- to disable replication (i.e. RFT) remove the -DRFT flag

				Command line options and parameters:
					- Run program passing "-" as argument

	Date:		14 April 2020
	Author:		Alexandre Huff
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include <rmr/rmr.h>

#include <rft/rft.h>
#include <rft/logger.h>

#include "exp.h"

// #define RFT

long global_state = 0;			// state replicated from another xapp (slave)

void	*mrc;					// msg router context
long	interval = 1000;		// range of time to check in miliseconds
long	threshold = 2000;		// limit of messages accepted in an interval
int		max_attempts = 1;		// max reply attempts using rmr_rts_msg

pthread_mutex_t timelock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t statelock = PTHREAD_MUTEX_INITIALIZER;


/* ===== Experiment variables ===== */
struct	timespec prev_time;
struct	timespec cur_time;

/* ===== stats variables ===== */
#if LOGGER_LEVEL >= LOGGER_INFO
	pthread_mutex_t count_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t reply_lock = PTHREAD_MUTEX_INITIALIZER;
	long	count = 0;			// only for reporting purposes
	long	last_count = 0;		// only for reporting purposes
#endif
long	replied = 0;
long	retries = 0;
long	errors = 0;
long	sfailed = 0;			// send/reply failed
/* ===== stats variables up to here ===== */


// function that will be called by the rft library
void apply_rstate( const int cmd, const char *context, const char *key, const unsigned char *data, const size_t dlen ) {

	switch ( cmd ) {
		case SET_STATE:
			pthread_mutex_lock( &statelock );		// lock state
			global_state = (long) *data;
			pthread_mutex_unlock( &statelock );		// unlock state
			break;

		case ADD_STATE:
			pthread_mutex_lock( &statelock );
			global_state += (long) *data;
			pthread_mutex_unlock( &statelock );
			break;

		case SUB_STATE:
			pthread_mutex_lock( &statelock );
			global_state -= (long) *data;
			pthread_mutex_unlock( &statelock );
			break;
	}

	// logger_warn( "replica's xapp state changed to %d", rep_state );
}


/*
	Computes the elapsed time between ts1 and ts2.
	Returns miliseconds.
*/
static inline long elapsed( struct timespec* start_ts, struct timespec* end_ts ) {
	long long start;
	long long end;

	start = ( start_ts->tv_sec * 1000000000) + start_ts->tv_nsec;
	end = ( end_ts->tv_sec * 1000000000) + end_ts->tv_nsec;

	return (long) (end - start) / 1000000;			// to miliseconds
}

/*
	This thread works as the listener of all incoming messages
	Its purpose is to unburden the RMR's receiver ring queue, and thus
	decreasing the number of dropped messages
*/
void *listener( ) {
	rmr_mbuf_t *mbuf = NULL;		// receiver buffer
	int			repeat;				// retries counter

	#if LOGGER_LEVEL >= LOGGER_WARN
		unsigned char target[RMR_MAX_SRC];
	#endif

	mbuf = rmr_alloc_msg( mrc, RMR_MAX_RCV_BYTES );
	if( ! mbuf ) {
		logger_error( "unable to allocate memory for message buffer" );
		exit( 1 );
	}

	// ===== Experiment =====
	ddos_request_t	*request;			// payload to receive messages
	ddos_reply_t 	*reply;				// payload to reply messages
	long			seq;				// message sequence number
	#ifdef RFT
		long		new_msg = 1;		// passed to the replicate function
	#endif

	while ( 1 ) { // listener for all incomming messages
		mbuf = rmr_rcv_msg( mrc, mbuf );

		if ( mbuf && mbuf->state == RMR_OK ) {

			switch ( mbuf->mtype ) {

				case APPEND_ENTRIES_REQ:
				case APPEND_ENTRIES_REPLY:
				case VOTE_REQ:
				case VOTE_REPLY:
				case MEMBERSHIP_REQ:
				case REPLICATION_REQ:
				case REPLICATION_REPLY:
					logger_trace( "%-*s type: %d, len: %3d, mrc: %p, msg: %p", LOGGER_PADDING, "receiving message", mbuf->mtype, mbuf->len, mrc, mbuf );

					#ifdef RFT
						rft_enqueue_msg( mbuf );
					#endif
					break;

				case REQUEST_MSG0:
				case REQUEST_MSG1:
				case REQUEST_MSG2:
				case REQUEST_MSG3:
				case REQUEST_MSG4:
					request = (ddos_request_t *) mbuf->payload;
					seq = request->seq;

					#ifdef RFT
						rft_replicate( ADD_STATE, "UE1", "key1", (unsigned char *) &new_msg, sizeof( new_msg ) );
					#endif

					pthread_mutex_lock( &timelock );		// time lock
					clock_gettime( CLOCK_REALTIME, &cur_time );
					if( elapsed( &prev_time, &cur_time ) > interval ) {
						pthread_mutex_lock( &statelock );	// state lock
						global_state = 0;
						pthread_mutex_unlock( &statelock );	// state unlock
						prev_time = cur_time;
					}
					pthread_mutex_unlock( &timelock );		// time unlock

					reply = (ddos_reply_t *) mbuf->payload;
					reply->seq = seq;

					pthread_mutex_lock( &statelock );	// state lock
					global_state++;
					if( global_state <= threshold ) {
						reply->status = ACK_MSG;
					} else {
						reply->status = NACK_MSG;
					}
					pthread_mutex_unlock( &statelock );	// state unlock

					mbuf->state = 0;
					mbuf->len = sizeof( *reply );

					repeat = max_attempts;
					do {
						mbuf = rmr_rts_msg( mrc, mbuf );

						repeat--;
					} while(repeat && mbuf && ( mbuf->state == RMR_ERR_SENDFAILED || mbuf->state == RMR_ERR_RETRY ) );

					if( mbuf != NULL ) {
						switch( mbuf->state ) {
							case RMR_OK:
								LOCK( &reply_lock );
								replied++;
								UNLOCK( &reply_lock );
								break;

							case RMR_ERR_SENDFAILED:
								sfailed++;
								#if LOGGER_LEVEL >= LOGGER_WARN
									logger_error( "send failed, mtype: %d, state: %d, strerr: %s\n",
												  mbuf->mtype, mbuf->state, strerror( errno ) );
								#endif
								break;

							case RMR_ERR_RETRY:
								retries++;
								#if LOGGER_LEVEL >= LOGGER_WARN
									if( max_attempts > 1 ) {	// only show retries by using reply loop (without loop generates a lot of retry messages)
										rmr_get_src( mbuf, target );
										strtok( (char *) target, ":" );	// replacing ':' to '\0'
										logger_warn( "message dropped with state RMR_ERR_RETRY, seq: %ld, target: %s, mtype: %d",
													reply->seq, (char *) target, mbuf->mtype );
									}
								#endif
								break;

							// case RMR_ERR_TIMEOUT:
							default:
								logger_error( "send error, state: %d, strerr: %s", mbuf->state, strerror( errno ) );
								errors++;
						}

					} else {
						logger_error( " extreme failure, unable to send message using RMR");
						exit( 1 );
					}

					LOCK( &count_lock );
					#if LOGGER_LEVEL >= LOGGER_INFO
						count++;
					#endif
					UNLOCK( &count_lock );

					break;

				default:
					logger_warn( "unrecognized message type: %d", mbuf->mtype);
				break;
			}
		} else {
			logger_error( "unable to receive message, type :%d, state: %d, errno: %d", mbuf->mtype, mbuf->state, errno );
		}
	}
}


int main( int argc, char **argv ) {
	int		i;
	int		ai = 1;					// argument index
	long	timeout;				// timeout to wait RMR configure routing table
	char	*listen_port = NULL;	// RMR port to exchange messages
	int		max_retries = 1;		// RMR max retries before giving up and returning to the xapp with RMR_ERR_RETRY
	char	wbuf[256];

	pthread_t *threads;
	int		nthreads = 1;			// number of receiver threads
	int		ret;					// general return code

	while( ai < argc ) {
		if( *argv[ai] == '-' ) {
			switch( argv[ai][1] ) {
				case 'p':
					ai++;
					listen_port = argv[ai];
					break;

				case 'r':
					ai++;
					max_retries = atoi( argv[ai] );
					break;

				case 'l':
					ai++;
					max_attempts = atoi( argv[ai] );
					break;

				case 'i':
					ai++;
					interval = strtol( argv[ai], NULL, 10 );
					break;

				case 't':
					ai++;
					threshold = strtol( argv[ai], NULL, 10 );
					break;

				case 'n':
					ai++;
					nthreads = atoi( argv[ai] );
					if( nthreads < 1 )
						nthreads = 1;
					break;

				default:
					fprintf( stderr, "[FAIL] unrecognized option: %s\n", argv[ai] );
					fprintf( stderr, "\nUsage: %s [-p port] [-r max_rmr_retries] [-l max attempts]"
									 " [-i interval ms] [-t threshold] [-n num_threads]\n", argv[0] );
					exit( 1 );
			}

			ai++;
		} else {
			break;		// not an option, leave with a1 @ first positional parm
		}
	}

	if( ! listen_port )
		listen_port = "4560";

	srand( time( NULL ) );

	if( getenv( "RMR_RTG_SVC" ) == NULL ) {		// setting random listener port
		snprintf( wbuf, sizeof(wbuf), "%d", 19000 + ( rand() % 1000 ) );
		setenv( "RMR_RTG_SVC", wbuf, 1 );		// set one that won't collide with the default port if running on same host
	}

	threads = (pthread_t *) malloc( nthreads * sizeof( pthread_t ) );
	if( threads == NULL ) {
		logger_error( "unable to allocate memory to initilize threads" );
		exit( 1 );
	}

	mrc = rmr_init( listen_port, RMR_MAX_RCV_BYTES, RMRFL_NONE );
	if( mrc == NULL ) {
		logger_error( "unable to initialize RMR" );
		exit( 1 );
	}
	rmr_set_fack( mrc );

	if( rmr_set_stimeout( mrc, max_retries ) != RMR_OK )
		logger_error( "unable to set rmr max retries" );

	timeout = time( NULL ) + 20;
	while( ! rmr_ready( mrc ) ) {								// wait for RMR configuring the route table
		logger_info( "waiting for RMR to show ready" );
		sleep( 1 );

		if( time( NULL ) > timeout ) {
			logger_error( "giving up" );
			exit( 1 );
		}
	}

	logger_info( "listening on port %s, threads: %d, max_attempts: %d, interval: %ld ms, threshold: %ld msgs",
				  listen_port, nthreads, max_attempts, interval, threshold );

	#ifdef RFT
		rft_init( mrc, listen_port, 1024*1024, apply_rstate );
	#endif

	clock_gettime( CLOCK_REALTIME, &prev_time );

	/* ===== Creating threads ===== */
	for( i = 0; i < nthreads; i++ ) {
		ret = pthread_create( &threads[i], NULL, listener, NULL );
		if( ret != 0 ) {
			logger_error( "error on creating thread: %s\n", strerror( ret ) );
			exit( 1 );
		}
	}

	/* ===== Stats ===== */
	#if LOGGER_LEVEL >= LOGGER_INFO
		while( 1 ) {
			sleep( 5 );
			if( last_count != count ) {
				logger_info( "========== Requests: %ld\tReplied: %ld\tRetries: %ld\tSend Failed: %ld\t\tErrors: %ld ==========",
							count, replied, retries, sfailed, errors );

				last_count = count;
			}
		}
	#endif

	// unreachable with LOGGER_INFO
	for( i = 0; i < nthreads; i++ ) {
		pthread_join( threads[i], NULL );
	}

	free( threads );

	return 0;
}

// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	ddos-redis.c
	Abstract:	Implements a multi-threaded xapp with global state properties
				by sharing a single global state among all xApp replicas instead
				of doing replication.
				Uses the Redis Async Event library to implement async calls

				The xApp state is maintained only in the external Redis store, thus
				all operations with the state needs to be done in the Redis server.
				This xApp only accepts an specific amount of requests during a specific
				time. The window of the time is controlled by the Redis store (i.e. the
				EXPIRE command is used to tell Redis to remove the key (global counter)
				when the time is reached). After the key is expired, the next increment
				command will initialize the global counter again as well as set the new
				expire time.

				Compilation flags:
					- use -DREDIS_SYNC to enable REDIS synchronous calls in compilation time
					- use -DREDIS_ASYNC to enable REDIS asynchronous calls in compilation time
					- REDIS_ASYNC is the default behaviour of this xApp implementation if none
					  of the above flags is set in the compilation time

				Command line options and parameters:
					- Run program passing "-" as argument

	Date:		23 April 2020
	Author:		Alexandre Huff
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>

#include <rmr/rmr.h>

#include <rft/rft.h>
#include <rft/logger.h>

#include <redis/ae.h>
#include <redis/hiredis/adapters/ae.h>

#include "exp.h"
#include "common/redis.c"


typedef struct recv_data {
	rmr_mbuf_t *mbuf;
	redisAsyncContext *rac;	// async context
	redisContext *rc;		// sync context
} recv_data_t;

// long global_state = 0;		// state replicated from another xapp (slave)	// FIXME remove if not required

void	*mrc;				// msg router context
long	interval = 1000;	// range of time to check in miliseconds
long	threshold = 2000;	// limit of messages accepted in an interval
int		max_attempts = 1;	// max reply attempts using rmr_rts_msg

char	*redis_host = NULL;
int		redis_port = 6379;

/* ===== Experiment variables ===== */
struct		timespec prev_time;
struct		timespec cur_time;

/* ===== stats variables ===== */
#if LOGGER_LEVEL >= LOGGER_INFO
	pthread_mutex_t count_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t reply_lock = PTHREAD_MUTEX_INITIALIZER;
	long	count = 0;			// only for reporting purposes
	long	last_count = 0;		// only for reporting purposes
#endif
long	replied = 0;
long	retries = 0;
long	errors = 0;
long	sfailed = 0;			// send/reply failed
/* ===== stats variables up to here ===== */

/*
	Implements an async callback function of the ddos_recv_handler

	The function arguments are those required by the Hiredis library

	It also is used to implement synchronous replies when compiled
	with the flag -DREDIS_SYNC
	In this case, the *ac argument can be NULL
*/
void ddos_reply_fn(redisAsyncContext *ac, void *r, void *privdata) {
	redisReply *rreply;				// redis reply
	rmr_mbuf_t *mbuf;
	ddos_request_t	*request;		// payload to receive messages
	ddos_reply_t 	*reply;			// payload to reply messages
	long			seq;			// message sequence number
	int				repeat;			// retries counter

	#if LOGGER_LEVEL >= LOGGER_WARN
		unsigned char target[RMR_MAX_SRC];
	#endif

	mbuf = (rmr_mbuf_t *) privdata;

	if( r == NULL ) {
		#ifdef REDIS_SYNC
			logger_error( "error on processing redis command: nil reply" );
		#else
			logger_error( "error on processing redis command (nil reply): %s", ac->errstr );
			rmr_free_msg( mbuf );
		#endif

		return;
	}

	rreply = (redisReply *) r;
	if( rreply->type == REDIS_REPLY_ERROR ) {
		logger_error( "%s", rreply->str );
		#ifndef REDIS_SYNC
			rmr_free_msg( mbuf );
		#endif

		return;
	}

	request = (ddos_request_t *) mbuf->payload;
	seq = request->seq;

	reply = (ddos_reply_t *) mbuf->payload;
	reply->seq = seq;

	if( rreply->integer <= threshold ) {
		reply->status = ACK_MSG;
	} else {
		reply->status = NACK_MSG;
	}

	mbuf->state = 0;
	mbuf->len = sizeof( *reply );

	repeat = max_attempts;
	do {
		mbuf = rmr_rts_msg( mrc, mbuf );

		repeat--;
	} while(repeat && mbuf && ( mbuf->state == RMR_ERR_SENDFAILED || mbuf->state == RMR_ERR_RETRY ) );

	if( mbuf != NULL ) {
		switch( mbuf->state ) {
			case RMR_OK:
				LOCK( &reply_lock );
				replied++;
				UNLOCK( &reply_lock );
				break;

			case RMR_ERR_SENDFAILED:
				sfailed++;
				#if LOGGER_LEVEL >= LOGGER_WARN
					logger_error( "[ERR] send failed, mtype: %d, state: %d, strerr: %s\n",
									mbuf->mtype, mbuf->state, strerror( errno ) );
				#endif
				break;

			case RMR_ERR_RETRY:
				retries++;
				#if LOGGER_LEVEL >= LOGGER_WARN
					if( max_attempts > 1 ) {	// only show retries by using reply loop (without loop generates a lot of retry messages)
						rmr_get_src( mbuf, target );
						strtok( (char *) target, ":" );	// replacing ':' to '\0'
						logger_warn( "message dropped with state RMR_ERR_RETRY, seq: %ld, target: %s, mtype: %d",
									reply->seq, (char *) target, mbuf->mtype );
					}
				#endif
			break;

			// case RMR_ERR_TIMEOUT:
			default:
				logger_error( "send error, state: %d, strerr: %s", mbuf->state, strerror( errno ) );
				errors++;
		}

	} else {
		logger_error( " extreme failure, unable to send message using RMR");
		exit( 1 );
	}

	LOCK( &count_lock );
	#if LOGGER_LEVEL >= LOGGER_INFO
		count++;
	#endif
	UNLOCK( &count_lock );

	#ifndef REDIS_SYNC
		rmr_free_msg( mbuf );
	#endif
}

void ddos_recv_handler( struct aeEventLoop *loop, int fd, void *privdata, int mask ) {
	recv_data_t *data = (recv_data_t *) privdata;

	#ifdef REDIS_SYNC
		redisReply *reply;
	#else
		rmr_mbuf_t *msg_copy;
	#endif

	#ifdef REDIS_SYNC
	while ( 1 ) { // listener for all incomming messages
	#endif
		data->mbuf = rmr_rcv_msg( mrc, data->mbuf );
		if ( data->mbuf && data->mbuf->state == RMR_OK ) {

			switch ( data->mbuf->mtype ) {

				case REQUEST_MSG0:
				case REQUEST_MSG1:
				case REQUEST_MSG2:
				case REQUEST_MSG3:
				case REQUEST_MSG4:
					#ifdef REDIS_SYNC
						reply = redis_sync_add_global_counter( data->rc, "counter", 1, interval );
						assert( reply != NULL );

						ddos_reply_fn( NULL, reply, data->mbuf );

						freeReplyObject( reply );

					#else
						msg_copy = rmr_realloc_payload( data->mbuf, data->mbuf->len, 1, 1 );
						redis_async_add_global_counter( data->rac, ddos_reply_fn, msg_copy, "counter", 1, interval );

					#endif

					break;

				default:
					logger_warn( "unrecognized message type: %d", data->mbuf->mtype);
				break;
			}
		} else {
			logger_error( "unable to receive message, type :%d, state: %d, errno: %d", data->mbuf->mtype, data->mbuf->state, errno );
		}
	#ifdef REDIS_SYNC
	}
	#endif
}

/*
	This thread works as the listener of all incoming messages
	Its purpose is to unburden the RMR's receiver ring queue, and thus
	decreasing the number of dropped messages
*/
void *listener( ) {
	recv_data_t data = { NULL };	// thread's private data

	data.mbuf = rmr_alloc_msg( mrc, RMR_MAX_RCV_BYTES );
	if( ! data.mbuf ) {
		logger_error( "unable to allocate memory for message buffer" );
		exit( 1 );
	}

	#ifdef REDIS_SYNC

		data.rc = redis_sync_init( redis_host, redis_port );

		ddos_recv_handler( NULL, 0, &data, 0 );	// the only argument required is the privdata (i.e. &data)

	#else

		data.rac = redis_async_init( redis_host, redis_port );

		aeEventLoop *loop = aeCreateEventLoop(64);
		redisAeAttach( loop, data.rac );

		int rmr_fd = rmr_get_rcvfd( mrc );
		assert( rmr_fd != -1 );

		aeCreateFileEvent( loop, rmr_fd, AE_READABLE, ddos_recv_handler, &data );

		logger_info( "ae_loop is going to run" );
		aeMain( loop );
		logger_info( "ae_loop has stopped" );

	#endif

	return NULL;
}


int main( int argc, char **argv ) {
	int		i;
	int		ai = 1;					// argument index
	long	timeout;				// timeout to wait RMR configure routing table
	char	*listen_port = NULL;	// RMR port to exchange messages
	int		max_retries = 1;		// RMR max retries before giving up and returning to the xapp with RMR_ERR_RETRY
	char	wbuf[256];

	pthread_t *threads;
	int		nthreads = 1;			// number of receiver threads
	int		ret;					// general return code

	while( ai < argc ) {
		if( *argv[ai] == '-' ) {
			switch( argv[ai][1] ) {
				case 'p':
					ai++;
					listen_port = argv[ai];
					break;

				case 'r':
					ai++;
					max_retries = atoi( argv[ai] );
					break;

				case 'l':
					ai++;
					max_attempts = atoi( argv[ai] );
					break;

				case 'i':
					ai++;
					interval = strtol( argv[ai], NULL, 10 );
					break;

				case 't':
					ai++;
					threshold = strtol( argv[ai], NULL, 10 );
					break;

				case 'n':
					ai++;
					nthreads = atoi( argv[ai] );
					if( nthreads < 1 )
						nthreads = 1;
					break;

				default:
					fprintf( stderr, "[FAIL] unrecognized option: %s\n", argv[ai] );
					fprintf( stderr, "\nUsage: %s [-p port] [-r max_rmr_retries] [-l max attempts]"
									 " [-i interval ms] [-t threshold] [-n num_threads]\n", argv[0] );
					exit( 1 );
			}

			ai++;
		} else {
			break;		// not an option, leave with a1 @ first positional parm
		}
	}

	if( ! listen_port )
		listen_port = "4560";

	srand( time( NULL ) );

	if( getenv( "RMR_RTG_SVC" ) == NULL ) {		// setting random listener port
		snprintf( wbuf, sizeof(wbuf), "%d", 19000 + ( rand() % 1000 ) );
		setenv( "RMR_RTG_SVC", wbuf, 1 );		// set one that won't collide with the default port if running on same host
	}

	/* Redis environment variables*/
	redis_host = getenv( "REDIS_HOST" );
	if( redis_host == NULL ) {
		redis_host = "localhost";
	}

	if( getenv( "REDIS_PORT" ) != NULL ) {
		redis_port = atoi( getenv( "REDIS_PORT" ) );
	}
	/* Redis environment variables up to here*/

	threads = (pthread_t *) malloc( nthreads * sizeof( pthread_t ) );
	if( threads == NULL ) {
		logger_error( "unable to allocate memory to initilize threads" );
		exit( 1 );
	}

	mrc = rmr_init( listen_port, RMR_MAX_RCV_BYTES, RMRFL_NONE );
	if( mrc == NULL ) {
		logger_error( "unable to initialize RMR" );
		exit( 1 );
	}
	rmr_set_fack( mrc );

	if( rmr_set_stimeout( mrc, max_retries ) != RMR_OK )
		logger_error( "unable to set rmr max retries" );

	timeout = time( NULL ) + 20;
	while( ! rmr_ready( mrc ) ) {								// wait for RMR configuring the route table
		logger_info( "waiting for RMR to show ready" );
		sleep( 1 );

		if( time( NULL ) > timeout ) {
			logger_error( "giving up" );
			exit( 1 );
		}
	}

	#if !defined(REDIS_SYNC) && !defined(REDIS_ASYNC)
		#ifdef RFT
			logger_error( "RFT is not supported in this implementation" );
		#endif
		logger_warn( "=============== Asynchronous Redis connection was enabled by default ===============" );
	#endif

	#if LOGGER_LEVEL >= LOGGER_INFO
		#ifdef REDIS_SYNC
			char *mode = "SYNC";
		#else
			char *mode = "ASYNC";
		#endif
	#endif

	logger_info( "listening on port %s, threads: %d, max_attempts: %d, interval: %ld ms, threshold: %ld msgs, redis conn: %s",
				  listen_port, nthreads, max_attempts, interval, threshold, mode );

	#ifdef REDIS_ASYNC
		signal( SIGPIPE, SIG_IGN );
	#endif

	clock_gettime( CLOCK_REALTIME, &prev_time );

	/* ===== Creating threads ===== */
	for( i = 0; i < nthreads; i++ ) {
		ret = pthread_create( &threads[i], NULL, listener, NULL );
		if( ret != 0 ) {
			logger_error( "error on creating thread: %s\n", strerror( ret ) );
			exit( 1 );
		}
	}

	/* ===== Stats ===== */
	#if LOGGER_LEVEL >= LOGGER_INFO
		while( 1 ) {
			sleep( 5 );
			if( last_count != count ) {
				logger_info( "========== Requests: %ld\tReplied: %ld \tRetries: %ld\tSend Failed: %ld\t\tErrors: %ld ==========",
							count, replied, retries, sfailed, errors );

				last_count = count;
			}
		}
	#endif

	// unreachable with LOGGER_INFO
	for( i = 0; i < nthreads; i++ ) {
		pthread_join( threads[i], NULL );
	}

	free( threads );

	return 0;
}

// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	redis.c
	Abstract:	Implements a wrapper of redis calls to replicate the state of xApps

	Date:		15 April 2020
	Author:		Alexandre Huff
*/

#include <stdlib.h>
#include <assert.h>

#include <redis/hiredis/hiredis.h>
#include <redis/hiredis/async.h>

#include <rft/logger.h>

#include "exp.h"


/* ##################### Synchronous API ##################### */

redisContext *redis_sync_init( char *host, int port ) {
	redisContext *c;

	assert( host != NULL );

	c = redisConnect( host, port );
	if( c == NULL || c->err ) {
		if (c) {
			logger_fatal( "unable to connect to redis server %s:%d, error: %s", host, port, c->errstr );
			redisFree(c);
		} else {
			logger_fatal( "unable to allocate redis context" );
		}
		exit(1);
	}
	logger_info( "connected to redis server %s:%d", host, port );

	return c;
}

/*
	Initializes the counters of the Cell Selector xApp in the Redis server
	Three counters are initialized with the "value" argument as their value

	Returns 1 on success, 0 otherwise
*/
int redis_sync_init_cell_counters( redisContext *c, const char *context, long value ) {
	redisReply *reply;

	reply = redisCommand( c, "DEL %s", context );
	if( reply == NULL ) {
		logger_fatal( "unable to remove the old context %s to initialize the cell counters", context );
		exit( 1 );
	}
	freeReplyObject( reply );
	
	reply = redisCommand( c, "RPUSH %s %ld %ld %ld", context, value, value, value );
	if( reply == NULL ) {
		logger_error( "RPUSH command error: %s", c->errstr );
		/*
			Once an error is returned the context cannot be reused and a new connection should be done
			We are only returning to the caller that the operation did not complete
		*/
		return 0;
	}
	freeReplyObject( reply );

	return 1;
}

/*
	Get counters of the "n_cells" stored in the Redis server identified by the "context" as the key
	Stores the returned result into the cell_counters array
	Assumes that "cell_counters" is allocated and at least size of "n_cells"

	Returns 1 on success, 0 otherwise
*/
int redis_sync_get_cell_counters( redisContext *c, const char *context, int *cell_counters, int n_cells ) {
	int i;
	redisReply *reply;
	
	reply = redisCommand( c, "LRANGE %s 0 %d", context, n_cells - 1 );	// -1 since range starts at 0
	if( reply == NULL ) {
		logger_error( "LRANGE command error: %s", c->errstr );
		/*
			Once an error is returned the context cannot be reused and a new connection should be done
			We are only returning to the caller that the operation did not complete
		*/
		return 0;
	}

	for( i = 0; i < reply->elements; i++ ) {
		cell_counters[i] = atoi( reply->element[i]->str );
	}

	freeReplyObject( reply );

	return 1;
}

void redis_sync_replicate( redisContext *c, int command, const char *context, const char *key, unsigned char *value, size_t len ) {
	redisReply *reply;

	switch( command ) {
		case ADD_STATE:
			/* ================ synchronous command ================ */
			reply = redisCommand( c, "INCRBY %s %ld", key, (long) *value );
			if( reply == NULL ) {
				logger_error( "command error: %s", c->errstr );
				/*
					Once an error is returned the context cannot be reused and you should set up a new connection
					An error message could be returned, but for the experiments we chose to exit the application
				*/
				if( redisReconnect( c ) != REDIS_OK ) {
					logger_fatal( "unable to reconnect using the previous redis context" );
					exit( 1 );
				}
			}
			// logger_warn( "redis reply: %lld", reply->integer );
			freeReplyObject( reply );
			break;

		default:
			logger_error( "unknown redis command: %d", command );
			break;
	}

}

/*
	Increments the "key" (global counter) using the argument "value"
	The key expires based on the milliseconds "ms" argument
	Synchronous implementation
*/
redisReply *redis_sync_add_global_counter( redisContext *c, const char *key, long value, long ms ) {
	redisReply *reply = NULL;

	/*
		KEYS[1] = key
		ARGV[1] = value
		ARGV[2] = ms
	*/
	char *lua = "local current "
				"current = redis.call(\"INCRBY\",KEYS[1],ARGV[1]) "
				"if tonumber(current) == tonumber(ARGV[1]) then "
					"redis.call(\"PEXPIRE\",KEYS[1],ARGV[2]) "
				"end "
				"return current";

	reply = redisCommand( c, "EVAL %s 1 %s %ld %ld", lua, key, value, ms );
	if( reply == NULL ) {
		logger_error( "command error: %s", c->errstr );
		/*
			Once an error is returned the context cannot be reused and you should set up a new connection
			An error message could be returned, but for the experiments we chose to exit the application
		*/
		if( redisReconnect( c ) != REDIS_OK ) {
			logger_fatal( "unable to reconnect using the previous redis context" );
			exit( 1 );
		}
	}

	return reply;
}

/*
	Generic function to retrieve the current value from a key (synchronous)

	NOTE: is the caller resposibility to free the returned object
		  with the freeReplyObject() function
*/
redisReply *redis_get_value( redisContext *c, char *key ) {
	redisReply *reply;

	reply = redisCommand( c, "GET %s", key );
	if( reply == NULL ) {
		logger_error( "command error: %s", c->errstr );
		/*
			Once an error is returned the context cannot be reused and you should set up a new connection
			An error message could be returned, but for the experiments we chose to exit the application
		*/
		if( redisReconnect( c ) != REDIS_OK ) {
			logger_fatal( "unable to reconnect using the previous redis context" );
			exit( 1 );
		}
	}
	return reply;
}


/* ##################### Assynchronous API ##################### */

void connect_callback( const redisAsyncContext *c, int status ) {
	if( status == REDIS_OK ) {
		logger_info( "async connection established to redis server" );
	} else {
		logger_fatal( "unable to establish async connection to redis server: %s", c->errstr );
		exit( 1 );
	}
}

void disconnect_callback( const redisAsyncContext *c, int status ) {
	if( status != REDIS_OK ) {
		logger_fatal( "redis async disconnected: %s", c->errstr );
		exit( 1 );
	}
	logger_info( "disconnected from async server" );
}

redisAsyncContext *redis_async_init( char *host, int port ) {
	assert( host != NULL );
	redisAsyncContext *c = redisAsyncConnect( host, port );
	if (c->err) {
		logger_fatal( "unable to create async connection to redis server %s:%d, error: %s", host, port, c->errstr );
		exit( 1 );
	}

	redisAsyncSetConnectCallback( c, connect_callback );
	redisAsyncSetDisconnectCallback( c, disconnect_callback );

	return c;
}

void add_state_callback( redisAsyncContext *ac, void *reply, void *privdata ) {
	if( reply == NULL ) {
		logger_error( "unable to increment the value for %s: %d", (char *) reply, ac->errstr );
	}

	// disconnect on every callback
	// redisAsyncDisconnect( c );
}

void redis_async_replicate( redisAsyncContext *ac, int command, const char *context, const char *key, unsigned char *value, size_t len ) {
	int r;

	switch( command ) {
		case ADD_STATE:
			r = redisAsyncCommand( ac, add_state_callback, NULL, "INCRBY %s %ld", key, (long) *value );
			if( r != REDIS_OK ) {
				logger_fatal( "unable to execute INCR command on redis server, key %s, fsm_command: %d", key, command );
				exit( 1 );
			}
			break;

		default:
			logger_error( "unknown FSM command: %d", command );
			break;
	}
}

/*
	Increments the "key" (global counter) using the argument "value"
	The key expires based on the milliseconds "ms" argument
	Asynchronous implementation
*/
void redis_async_add_global_counter( redisAsyncContext *ac, void *callback_fn, rmr_mbuf_t *mbuf, const char *key, long value, long ms ) {
	int r;

	/*
		KEYS[1] = key
		ARGV[1] = value
		ARGV[2] = ms
	*/
	char *lua = "local current "
				"current = redis.call(\"INCRBY\",KEYS[1],ARGV[1]) "
				"if tonumber(current) == tonumber(ARGV[1]) then "
					"redis.call(\"PEXPIRE\",KEYS[1],ARGV[2]) "
				"end "
				"return current";

	r = redisAsyncCommand( ac, callback_fn, mbuf, "EVAL %s 1 %s %ld %ld", lua, key, value, ms );
	if( r != REDIS_OK ) {
		logger_fatal( "unable to execute global increment script on redis server, key %s", key );
		exit( 1 );
	}
}


/*
	Implements a callback from an async GET call of a string
*/
// void get_callback(redisAsyncContext *c, void *r, void *privdata) {
// 	redisReply *reply;

// 	if( r == NULL )
// 		return;

// 	reply = (redisReply *) r;

// 	logger_info( "%s = %s", (char *) privdata, reply->str );

// 	/* Disconnect after receiving the reply to GET */
// 	// redisAsyncDisconnect( c );
// }

void redis_async_get_value( redisAsyncContext *ac, void *callback_fn, const char *key ) {
	int r;

	r = redisAsyncCommand( ac, callback_fn, (char *) key, "GET %s", key );
	if( r != REDIS_OK ) {
		logger_fatal( "unable to execute GET %s command on redis server", key );
		exit( 1 );
	}
}

/*
	Starts a transaction in the Redis server
*/
void redis_async_watch( redisAsyncContext *ac, const char *key ) {
	int r;

	r = redisAsyncCommand( ac, NULL, NULL, "WATCH %s", key );
	if( r != REDIS_OK ) {
		logger_fatal( "unable to execute WATCH %s command on redis server", key );
		exit( 1 );
	}
}

/*
	Finishes a transaction in the Redis server

	Flushes all previously queued commands in a transaction and restores the connection state to normal
*/
void redis_async_discard( redisAsyncContext *ac ) {
	int r;

	r = redisAsyncCommand( ac, NULL, NULL, "DISCARD" );
	if( r != REDIS_OK ) {
		logger_fatal( "unable to execute DISCARD command on redis server" );
		exit( 1 );
	}
}

/*
	Unwatches a transaction in the Redis server

	FFlushes all the previously watched keys for a transaction
*/
void redis_async_unwatch( redisAsyncContext *ac ) {
	int r;

	r = redisAsyncCommand( ac, NULL, NULL, "UNWATCH" );
	if( r != REDIS_OK ) {
		logger_fatal( "unable to execute UNWATCH command on redis server" );
		exit( 1 );
	}
}

/*
	Get counters of the "n_cells" stored in the Redis server identified by the "context" as the key
*/
void redis_async_get_cell_counters( redisAsyncContext *ac, void *callback_fn, rmr_mbuf_t *mbuf, const char *context, int n_cells ) {
	int r;
	
	r = redisAsyncCommand( ac, callback_fn, mbuf, "LRANGE %s 0 %d", context, n_cells - 1 );	// -1 since range starts at 0
	if( r != REDIS_OK ) {
		logger_fatal( "LRANGE command error: %s", ac->errstr );
		exit( 1 );
	}
}

/*
	Checks and set the src and dst cell counters only if they were not changed since last read

	Executes the transaction (atomic commands)
*/
void redis_async_set_cell_counters( redisAsyncContext *ac, void *callback_fn, tr_data_t *fn_data, const char *context,
									int src_idx, int dst_idx, int src_value, int dst_value ) {
	int r;

	// logger_info( "src_idx: %d, dst_idx: %d, src_value: %d, dst_value: %d", src_idx, dst_idx, src_value, dst_value );
	
	r = redisAsyncCommand( ac, NULL, NULL, "MULTI" );	// starts the transaction
	if( r != REDIS_OK ) {
		logger_fatal( "MULTI command error: %s", ac->errstr );
		exit( 1 );
	}

	r = redisAsyncCommand( ac, NULL, NULL, "LSET %s %d %d", context, src_idx - 1, src_value );
	if( r != REDIS_OK ) {
		logger_fatal( "LSET command error: %s", ac->errstr );
		exit( 1 );
	}

	r = redisAsyncCommand( ac, NULL, NULL, "LSET %s %d %d", context, dst_idx - 1, dst_value );
	if( r != REDIS_OK ) {
		logger_fatal( "LSET command error: %s", ac->errstr );
		exit( 1 );
	}

	r = redisAsyncCommand( ac, callback_fn, fn_data, "EXEC" );	// executes the transaction and releases the WATCHED keys
	if( r != REDIS_OK ) {
		logger_fatal( "EXEC command error: %s", ac->errstr );
		exit( 1 );
	}

}

/*
	Implements the cell handover in redis server using a lua script

	Cell handover is based on the signal strength and UE counts among 3 different cells
*/
void redis_async_handover( redisAsyncContext *ac, void *callback_fn, rmr_mbuf_t *mbuf, char *lua_script, char *context,
							int src_cell, int *signals, int max_ue ) {
	int r;

	/*
		-- KEYS[1] : the context (key in redis)
		-- ARGV[1] : the number of cells to check in the array
		-- ARGV[2] : the src cell index starting by 1 (needs to increment before passing to redis)
		-- ARGV[3-5]: the cell signals
		-- ARGV[6]: the max UE a cell can accept
	*/

	// logger_info( "src_cell: %d, signals[ %2d, %2d, %2d ]", src_cell, signals[0], signals[1], signals[2] );

	r = redisAsyncCommand( ac, callback_fn, mbuf, "EVAL %s 1 %s %d %d %d %d %d %d", lua_script, context, 3, src_cell,
							signals[0], signals[1], signals[2], max_ue );
	if( r != REDIS_OK ) {
		logger_fatal( "unable to execute handover script on redis server" );
		exit( 1 );
	}
}

-- KEYS[1] : the context (key in redis)
-- ARGV[1] : the number of cells to check in the array
-- ARGV[2] : the src cell index starting by 1
-- ARGV[3-5]: the cell signals
-- ARGV[6]: the max UE a cell can accept
local ncells = tonumber(ARGV[1])
local cells = redis.call("LRANGE", KEYS[1], 0, ncells-1)
local src_cell = tonumber(ARGV[2])
local signals = {tonumber(ARGV[3]), tonumber(ARGV[4]), tonumber(ARGV[5])}
local max_ue = tonumber(ARGV[6])
local dst_cell = -1
local max_value = -1
local loop = ncells
local value

repeat
    loop = loop - 1
    dst_cell = 1
    max_value = signals[1]
    for i = 1, ncells do
        if signals[i] > max_value then
            dst_cell = i
            max_value = signals[i]
        end
    end
    if( dst_cell ~= src_cell ) then   -- not
        if( (tonumber(cells[dst_cell]) < max_ue) and (tonumber(cells[src_cell]) > 0) ) then
            loop = 0
            value = cells[dst_cell] + 1
            redis.call("LSET", KEYS[1], dst_cell - 1, value )
            value = cells[src_cell] - 1
            redis.call("LSET", KEYS[1], src_cell - 1, value )
        else
            signals[dst_cell] = -1    -- reset it to not be the max again
            dst_cell = -1
        end
    else
        loop = 0    -- the strongest signal is the src_cell
    end

until( loop == 0 )

return dst_cell

// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

	   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	cell-redis-lua.c
	Abstract:	Implements an Cell Selector xapp with partial replication properties
				A cell is selected based on signal stregth and a threshold of max UE supported in that cell

				Command line options and parameters:
					- Run program passing "-" as argument

	Date:		29 May 2020
	Author:		Alexandre Huff
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <rmr/rmr.h>

#include <redis/ae.h>
#include <redis/hiredis/adapters/ae.h>

#include <rft/logger.h>

#include "exp.h"
#include "common/redis.c"

/* function prototypes */

void cell_handover_handler_fn( redisAsyncContext *ac, void *r, void *privdata );

/* function prototypes up to here */

typedef struct cell_data {
	int from_cell;
	int to_cell;
} cell_data_t;

typedef struct recv_data {
	rmr_mbuf_t *msg;
	redisAsyncContext *rac;	// async context
	// redisContext *rc;		// sync context
} recv_data_t;

void	*mrc;					// msg router context
int		max_attempts = 1;		// max reply attempts using rmr_rts_msg
char	*redis_host = NULL;
int		redis_port = 6379;


/* ===== Experiment variables ===== */
long	max_ue = 50;			// max UE admitted in a cell
/*
	the hostname used as the cell context
	in this experiment the cell context is pretended by the xApp's hostname
*/
char	context[128];
char	*lua_script = NULL;	


/* ===== stats variables ===== */
#if LOGGER_LEVEL >= LOGGER_INFO
	pthread_mutex_t count_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t reply_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t trans_retries_lock = PTHREAD_MUTEX_INITIALIZER;
	long	count = 0;			// only for reporting purposes
	long	last_count = 0;		// only for reporting purposes
	/* counts the number of times the transaction failed due to changes of the key by another thread/xApp */
	long	transaction_retries = 0;
#endif
long	replied = 0;
long	retries = 0;
long	errors = 0;
long	timeouts = 0;
long	sfailed = 0;			// send/reply failed
/* ===== stats variables up to here ===== */


/*
	Implements the logic to reply messages to the WG
*/
void reply_msg( rmr_mbuf_t *mbuf ) {
	int repeat;
	rmr_mbuf_t *msg = mbuf;	// we have to keep the mbuf pointer to free it (it was cloned) to avoid memory likage

	repeat = max_attempts;
	do {
		msg = rmr_rts_msg( mrc, msg );

		repeat--;
	} while(repeat && msg && ( msg->state == RMR_ERR_SENDFAILED || msg->state == RMR_ERR_RETRY ) );

	if( msg != NULL ) {
		switch( msg->state ) {
			case RMR_OK:
				LOCK( &reply_lock );
				replied++;
				UNLOCK( &reply_lock );
				break;

			case RMR_ERR_SENDFAILED:
				sfailed++;
				#if LOGGER_LEVEL >= LOGGER_WARN
					logger_error( "send failed, mtype: %d, state: %d, strerr: %s\n",
									msg->mtype, msg->state, strerror( errno ) );
				#endif
				break;

			case RMR_ERR_RETRY:
				retries++;
				#if LOGGER_LEVEL >= LOGGER_WARN
					unsigned char target[RMR_MAX_SRC];
					hand_reply_t *reply = (hand_reply_t *) msg->payload;
					if( repeat == 0 ) {		// only show retries by using rts loop (without loop generates a lot of retry messages)
						rmr_get_src( msg, target );
						strtok( (char *) target, ":" );	// replacing ':' to '\0'
						logger_warn( "message dropped with state RMR_ERR_RETRY, seq: %ld, target: %s, mtype: %d",
									reply->seq + 1, (char *) target, msg->mtype );
					}
				#endif
				break;

			// case RMR_ERR_TIMEOUT:
			default:
				logger_error( "send error, state: %d, strerr: %s", msg->state, strerror( errno ) );
				errors++;
		}

	} else {
		logger_error( " extreme failure, unable to send message using RMR");
		exit( 1 );
	}

	if( mbuf != msg )
		rmr_free_msg( mbuf );
	rmr_free_msg( msg );
}

/*
	Implements an async callback function of the cell_recv_handler
*/
void cell_handover_handler_fn( redisAsyncContext *ac, void *r, void *privdata ) {
	redisReply *redis_reply = r;
	rmr_mbuf_t *msg = (rmr_mbuf_t *) privdata;

	// ===== Experiment =====
	hand_request_t	*request;			// payload received in the experiment
	hand_reply_t	*reply;				// payload sent back to the WG
	long			msg_seq;
	int dst_cell = -1;

	if( redis_reply == NULL ) {
		rmr_free_msg( msg );
		return;
	}
	if( redis_reply->type == REDIS_REPLY_ERROR ) {
		logger_fatal( "error on running the handover lua script on redis server: %s", redis_reply->str );
		rmr_free_msg( msg );
		exit( 1 );
	}

	dst_cell = redis_reply->integer;

	request = (hand_request_t *) msg->payload;
	msg_seq = request->seq;
	
	if( request->src_cell == dst_cell ) {
		dst_cell = -1;	// the lua script also returns -1 in case of unable to handover
	}

	reply = (hand_reply_t *) msg->payload;
	reply->seq = msg_seq;
	reply->dst_cell = dst_cell;
	if( dst_cell != -1 ) {
		msg->mtype = HAND_ACK;
	} else {
		msg->mtype = HAND_NACK;
	}
	
	reply_msg( msg );
	
}

void cell_recv_handler( struct aeEventLoop *loop, int fd, void *privdata, int mask ) {
	recv_data_t *data = (recv_data_t *) privdata;
	rmr_mbuf_t *msg_copy;
	hand_request_t *request;

	data->msg = rmr_rcv_msg( mrc, data->msg );

	if ( data->msg && data->msg->state == RMR_OK ) {

		switch ( data->msg->mtype ) {

			case HAND_REQUEST0:
			case HAND_REQUEST1:
			case HAND_REQUEST2:
			case HAND_REQUEST3:
			case HAND_REQUEST4:
				msg_copy = rmr_realloc_payload( data->msg, data->msg->len, 1, 1 );
				if( msg_copy == NULL ) {
					logger_fatal( "unable to clone the RMR message buffer, error:", strerror( errno ) );
					exit( 1 );
				}

				request = (hand_request_t *) msg_copy->payload;

				redis_async_handover( data->rac, cell_handover_handler_fn, msg_copy, lua_script, context,
									request->src_cell, request->signals, max_ue );

				LOCK( &count_lock );
				#if LOGGER_LEVEL >= LOGGER_INFO
					count++;	// requests counter
				#endif
				UNLOCK( &count_lock );

				break;
			
			default:
				logger_warn( "unrecognized message type: %d", data->msg->mtype);
			break;
		}

	} else {
		logger_error( "unable to receive message, type :%d, state: %d, errno: %d", data->msg->mtype, data->msg->state, errno );
	}

}

/*
	This thread works as the listener of all incoming messages
	Its purpose is to unburden the RMR's receiver ring queue, and thus
	decreasing the number of dropped messages
*/
void *listener( ) {
	recv_data_t data = { NULL };	// thread's private data

	data.rac = redis_async_init( redis_host, redis_port );

	aeEventLoop *loop = aeCreateEventLoop(64);
	redisAeAttach( loop, data.rac );

	int rmr_fd = rmr_get_rcvfd( mrc );
	assert( rmr_fd != -1 );

	aeCreateFileEvent( loop, rmr_fd, AE_READABLE, cell_recv_handler, &data );

	logger_info( "ae_loop is going to run" );
	aeMain( loop );
	logger_info( "ae_loop has stopped" );

	return NULL;
}

/*
	Generic function to read the content of a regular file into a buffer

	Returns a pointer to the read buffer, NULL on error
	It is the caller resposibility to free the allocated memory
*/
char *read_file( char *filename ) {
	int ret;
	FILE *fp;
	struct stat sb;		// fstat buffer
	char *buffer;

	fp = fopen( filename, "r" );
	if( fp == NULL ) {
		logger_error( "unable to open file %s, reason: %s\n", filename, strerror( errno ) );
		return NULL;
	}
	ret = fstat( fileno(fp), &sb );
	if( ( ret == -1 ) || ( !S_ISREG( sb.st_mode ) ) ) {
		logger_error( "unable getting stat of the regular file %s, reason: %s\n", filename, strerror( errno ) );
		fclose( fp );
		return NULL;
	}
	buffer = malloc( sizeof(char) * sb.st_size + 1);	// assuring 1 byte for the \0 char
	if( buffer == NULL ) {
		logger_error( "unable to allocate memory for the file buffer: %s", strerror(errno) );
		fclose( fp );
		return NULL;
	}
	memset( buffer, 0, sb.st_size + 1);
	if( fread( buffer, 1, sb.st_size, fp ) != sb.st_size ) {
		logger_error( "unable to read file into buffer: %s", strerror(errno) );
		fclose( fp );
		return NULL;
	}

	fclose( fp );

	return buffer;
}

int main( int argc, char **argv ) {
	int 		ai = 1;					// argument index
	long		timeout;				// timeout to wait RMR configure routing table
	char		*listen_port = NULL;	// RMR port to exchange messages
	int			max_retries = 1;		// RMR max retries before giving up and returning to the xapp with RMR_ERR_RETRY
	char		wbuf[256];
	int			i;
	int			err;					// error on getting the xApp's hostname

	pthread_t	*threads;
	int			nthreads = 1;			// number of receiver threads
	int			ret;					// general return code

	while( ai < argc ) {
		if( *argv[ai] == '-' ) {
			switch( argv[ai][1] ) {
				case 'p':
					ai++;
					listen_port = argv[ai];
					break;

				case 'r':
					ai++;
					max_retries = atoi( argv[ai] );
					break;

				case 'l':
					ai++;
					max_attempts = atoi( argv[ai] );
					break;

				case 'm':
					ai++;
					max_ue = atoi( argv[ai] );
					break;
				
				case 'n':
					ai++;
					nthreads = atoi( argv[ai] );
					if( nthreads < 1 )
						nthreads = 1;
					break;

				default:
					fprintf( stderr, "[FAIL] unrecognized option: %s\n", argv[ai] );
					fprintf( stderr, "\nUsage: %s [-p port] [-r max_rmr_retries] [-l max attempts]"
									 " [-m max UEs per cell] [-n num_threads]\n", argv[0] );
					exit( 1 );
			}

			ai++;
		} else {
			break;		// not an option, leave with a1 @ first positional parm
		}
	}

	err = gethostname( context, sizeof( context ) );
	if ( err != 0 ) {
		if ( errno == ENAMETOOLONG )
			logger_fatal( "hostname too long for context name" );
		else
			logger_fatal( "error on getting hostname for context name, errno: %d", errno );
		exit( 1 );
	}

	/* Redis environment variables*/
	redis_host = getenv( "REDIS_HOST" );
	if( redis_host == NULL ) {
		redis_host = "localhost";
	}

	if( getenv( "REDIS_PORT" ) != NULL ) {
		redis_port = atoi( getenv( "REDIS_PORT" ) );
	}
	/* Redis environment variables up to here*/

	// getting lua script
	logger_info( "loading handover lua script" );
	lua_script = read_file( "src/common/handover.lua" );
	if( lua_script == NULL ) {
		logger_fatal( "unable to read lua script: %s", strerror(errno) );
		exit( 1 );
	}

	if( ! listen_port )
		listen_port = "4560";

	srand( time( NULL ) );

	if( getenv( "RMR_RTG_SVC" ) == NULL ) {		// setting random listener port
		snprintf( wbuf, sizeof(wbuf), "%d", 19000 + ( rand() % 1000 ) );
		setenv( "RMR_RTG_SVC", wbuf, 1 );		// set one that won't collide with the default port if running on same host
	}

	threads = (pthread_t *) malloc( nthreads * sizeof( pthread_t ) );
	if( threads == NULL ) {
		logger_error( "unable to allocate memory to initilize threads" );
		exit( 1 );
	}

	mrc = rmr_init( listen_port, RMR_MAX_RCV_BYTES, RMRFL_NONE );	// start your engines!
	if( mrc == NULL ) {
		logger_error( "unable to initialize RMR" );
		exit( 1 );
	}
	rmr_set_fack( mrc );

	if( rmr_set_stimeout( mrc, max_retries ) != RMR_OK )
		logger_error( "unable to set rmr max retries" );

	timeout = time( NULL ) + 20;
	while( ! rmr_ready( mrc ) ) {								// wait for RMR configuring the route table
		logger_info( "waiting for RMR to show ready" );
		sleep( 1 );

		if( time( NULL ) > timeout ) {
			logger_error( "giving up" );
			exit( 1 );
		}
	}

	logger_info( "listening on port %s, threads: %d, max_attempts: %d, max UEs/cell: %d",
				  listen_port, nthreads, max_attempts, max_ue );

	signal( SIGPIPE, SIG_IGN );		// ignoring sigpipe, required by redis library

	// initializing cell counters to half of the max
	redisContext *rc = redis_sync_init( redis_host, redis_port );
	if( !redis_sync_init_cell_counters( rc, context, max_ue / 2 ) ) {
		logger_error( "unable to set the initial cell counters for context %s", context );
		exit( 1 );
	}

	int cells[3];
	redis_sync_get_cell_counters( rc, context, cells, 3 );

	logger_info( "initial cell: [ %3d, %3d, %3d ]", cells[0], cells[1], cells[2] );

	/* ===== Creating threads ===== */
	for( i = 0; i < nthreads; i++ ) {
		ret = pthread_create( &threads[i], NULL, listener, NULL );
		if( ret != 0 ) {
			logger_error( "error on creating thread: %s\n", strerror( ret ) );
			exit( 1 );
		}
	}

	/* ===== Stats ===== */
	#if LOGGER_LEVEL >= LOGGER_INFO
		int local_cells[3];	 // counter of the number of UE connected on three cells
		while( 1 ) {
			sleep( 5 );
			if( last_count != count ) {
				if( !redis_sync_get_cell_counters( rc, context, local_cells, 3 ) ) {
					logger_fatal( "unable to get cell counters for context %s from redis server", context );
					exit( 1 );
				}
				logger_info( "========== Requests: %ld\tReplied: %ld\tRetries: %ld\tSend Failed: %ld\t\tErrors: %ld \tTransaction Retries: %ld ==========",
							count, replied, retries, sfailed, errors, transaction_retries );
				logger_info( "========== local_cells: [ %3d, %3d, %3d ] ==========", local_cells[0], local_cells[1], local_cells[2] );

				last_count = count;
			}
		}
	#endif

	redisFree( rc );

	// unreachable with LOGGER_INFO
	for( i = 0; i < nthreads; i++ ) {
		pthread_join( threads[i], NULL );
	}

	free( threads );
	free( lua_script );

	return 0;
}

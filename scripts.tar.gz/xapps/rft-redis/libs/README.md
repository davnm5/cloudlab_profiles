# Redis library dependencies

This directory contains static libraries that this project depends on.
These libraries are compiled from the source code of the [Redis](https://redis.io/download) main project. This is only required if the Redis development files are not installed in the system, and the developer does not plan to install them in the system.

## How-To

1. Download the [Redis](https://redis.io/download) source code and compile it following its building process

1. Create a static library of the redis project with the following commands:

		$ cd (redisdir)/src/
		$ ar rcvs libredis.a *.o

1. The ``lihiredis.a`` and ``libjemalloc.a`` were automatically created during the building process of the Redis project

1. Copy the three static libraries to their respective directory in this project according to the following structure:

## Directory structure

| Source										| Destination			|
| ---											| ---					|
| (redisdir)/src/libredis.a						| libs/libredis.a		|
| (redisdir)/deps/hiredis/libhiredis.a			| libs/libhiredis.a		|
| (redisdir)/deps/jemalloc/lib/libjemalloc.a	| libs/libjemalloc.a	|

**NOTE:** The header files located in the ``include/redis`` directory also need to be updated to avoid incompatibility issues with the new library version.

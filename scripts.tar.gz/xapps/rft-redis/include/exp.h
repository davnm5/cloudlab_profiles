// :vim ts=4 sw=4 noet:
/*
==================================================================================
	Copyright (c) 2020 AT&T Intellectual Property.

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
==================================================================================
*/

/*
	Mnemonic:	exp.h
	Abstract:	Header file used to run experiments to the Middleware conference

	Date:		29 May 2020
	Author:		Alexandre Huff
*/

#ifndef _EXP_H
#define _EXP_H

// commands for the state machine
enum commands {
	SET_STATE,			// DDoS
	ADD_STATE,			// DDoS
	SUB_STATE,			// DDoS
	CHG_HANDOVER_STATE	// Cell
};

#define HASHTABLE_SIZE	31

// ddos experiment
#define REQUEST_MSG0	500
#define REQUEST_MSG1	501
#define REQUEST_MSG2	502
#define REQUEST_MSG3	503
#define REQUEST_MSG4	504

// cell selector experiment
#define HAND_REQUEST0	600
#define HAND_REQUEST1	601
#define HAND_REQUEST2	602
#define HAND_REQUEST3	603
#define HAND_REQUEST4	604

#define HAND_ACK		605
#define HAND_NACK		606

#if LOGGER_LEVEL >= LOGGER_INFO
	#define LOCK( mutex ) pthread_mutex_lock( mutex )
	#define UNLOCK( mutex ) pthread_mutex_unlock( mutex )
#else
	#define LOCK( mutex )
	#define UNLOCK( mutex )
#endif

/*
	Macro to add nanoseconds in a timespec
*/
#define timespec_add_ns(a, ns)				\
	do {									\
		(a).tv_sec += ns / 1000000000;		\
		(a).tv_nsec += ( ns % 1000000000 );	\
		if ( (a).tv_nsec >= 1000000000 ) {	\
			(a).tv_sec++;					\
			(a).tv_nsec -= 1000000000;		\
		}									\
	} while (0)


typedef enum mstatus {
	NACK_MSG = 0,
	ACK_MSG = 1
} mstatus_t;

/*
	DDoS request message payload
*/
typedef struct ddos_request {
	long num_msgs;
	long seq;
} ddos_request_t;

/*
	DDoS reply message payload
*/
typedef struct ddos_reply {
	long seq;
	mstatus_t status;
} ddos_reply_t;

/*
	Request message of the Cell Selector experiment
*/
typedef struct hand_request {
	int signals[3];		// signal strengh of our three cells
	int src_cell;		// carries which cell that UE is currently connected to (ranges from 1 to 3)
	long seq;
} hand_request_t;

/*
	Reply message of the Cell Selector experiment
*/
typedef struct hand_reply {
	int dst_cell;		// carries which cell that UE must connect to (ranges from 1 to 3)
	long seq;
} hand_reply_t;

/*
	Transaction private data to pass to the callback of the Cell Selector
*/
typedef struct tr_data {
	rmr_mbuf_t *mbuf;
	long msg_seq;
	int dst_cell;
} tr_data_t;


#endif

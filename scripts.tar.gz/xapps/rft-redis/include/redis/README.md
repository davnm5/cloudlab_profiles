# Redis header dependencies

This directory contains the header dependencies from the [Redis](https://redis.io/download) main project to implement and compile xApps. Copy the following files from the downloaded Redis project to the respective directory in this project according to the following structure.

## Directory structure

| Source									| Destination						|
| ---										| ---								|
| (redisdir)/src/ae.h						| include/ae.h						|
| (redisdir)/deps/hiredis/async.h			| include/hiredis/async.h			|
| (redisdir)/deps/hiredis/hiredis.h			| include/hiredis/hiredis.h			|
| (redisdir)/deps/hiredis/read.h			| include/hiredis/read.h			|
| (redisdir)/deps/hiredis/sds.h				| include/hiredis/sds.h				|
| (redisdir)/deps/hiredis/adapters/ae.h		| include/hiredis/adapters/ae.h		|
| (redisdir)/deps/hiredis/adapters/libuv.h	| include/hiredis/adapters/libuv.h	|

**NOTE:** These files need to be replaced when downloading a new version of the Redis project.

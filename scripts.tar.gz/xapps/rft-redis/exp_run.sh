#!/bin/bash

# RMR message type
MTYPE=600

# Workload generator port
PORT=4570

# Number of xApp instances
XAPPS=1

# Number of request messages
REQUESTS=100000

HOST=`hostname`

EXP_NAME="cell-selector"
DIR="logs"
#OUT_PREFIX="${DIR}/${EXP_NAME}-${HOST}-${XAPPS}xApp-RFT"
#OUT_PREFIX="${DIR}/${EXP_NAME}-${HOST}-${XAPPS}xApp-Redis"
OUT_PREFIX="${DIR}/${EXP_NAME}-${HOST}-${XAPPS}xApp-Redis-lua"

OUT_SUFFIX=".csv"

case $HOST in
    sender1)
        ;;

    sender2)
        MTYPE=$(($MTYPE + 1))
        PORT=$(($PORT + 1))
        ;;

    sender3)
        MTYPE=$(($MTYPE + 2))
        PORT=$(($PORT + 2))
        ;;

    sender4)
        MTYPE=$(($MTYPE + 3))
        PORT=$(($PORT + 3))
        ;;
    
    sender5)
        MTYPE=$(($MTYPE + 4))
        PORT=$(($PORT + 4))
        ;;

    *)
        echo "The hostname of the workload generator must be sender{1-5}"
        exit 1
esac

for i in {1..250}
do
    echo -e "\nRunning round $i...\n"
    # =============================================================================
    # out_file="${OUT_PREFIX}-distribution-round$i${OUT_SUFFIX}"
    # ./ddos-sender -p $PORT -m $MTYPE -n $REQUESTS -o $out_file -v
    # ./cell-sender -p $PORT -m $MTYPE -n $REQUESTS -o $out_file -v

    # =============================================================================
    out_file="${OUT_PREFIX}${OUT_SUFFIX}"
    # ./ddos-sender -p $PORT -m $MTYPE -n $REQUESTS -o $out_file
    ./cell-sender -p $PORT -m $MTYPE -n $REQUESTS -o $out_file

    # =============================================================================
    # Run in a very slow peace
    # out_file="${OUT_PREFIX}-1msg-1msec${OUT_SUFFIX}"
    # ./cell-sender -p $PORT -m $MTYPE -n $REQUESTS -e -i 1000 -c 1 -o $out_file

    echo -e " "
    sleep 2
done

result=$(kubectl get pods --no-headers -o custom-columns=":metadata.name" | grep sender)

kubectl cp $result:/xapp/logs/cell-selector-sender1-1xApp-Redis-lua.csv /mnt/extra/file.csv

exit 0

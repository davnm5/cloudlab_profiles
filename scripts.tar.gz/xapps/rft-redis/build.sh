#!/bin/bash

sudo docker build -t middleware .

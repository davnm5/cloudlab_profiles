#!/bin/bash

CMD=$2

# Default command
# docker run --rm --network xapp-net --name $1 --hostname $1 --add-host=`hostname`:172.18.0.1 -it middleware $CMD

# To map a host port to a container port
# docker run --rm --network xapp-net --name $1 --hostname $1 --add-host=`hostname`:172.18.0.1 -p 4560:4560 -it middleware $CMD

# To configure an environment variable
# docker run --rm --network xapp-net --name $1 --hostname $1 -e RAFT_BOOTSTRAP=xapp1 -it middleware

# To run a container using the host network (no bridges and overlays)
docker run --rm --network host --name $1 --hostname $1 -it middleware $CMD

# To run and map (bind) a host directory in the container
# docker run --rm --mount type=bind,src=/home/alexandre/Documents/Doutorado/Experiments/Middleware/logs,dst=/logs --network host --name $1 --hostname $1 -it middleware $CMD
# On larsis machine
# docker run --rm --mount type=bind,src=/home/alexandre/middleware/logs,dst=/logs --network host --name $1 --hostname $1 -it middleware $CMD

# To run the redis server using the host network
# docker run --rm --network host --name redis -it redis

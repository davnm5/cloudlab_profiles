#!/bin/bash

# This script drives the workload generator execution
# Experiments should be run using this script on host machine (bare metal)

CMD="/xapp/exp_run.sh"
HOST=`hostname`

case $HOST in
    huff)
        LOG_DIR="/home/alexandre/Documents/Experiments/Middleware/logs"
        ;;
    tacker-vim)
        LOG_DIR="/home/alexandre/middleware/logs"
        ;;
    *)
        echo -e "The hostname should be { huff | tacker-vim }"
        exit 1
esac

for i in {1..2}
do
    /usr/bin/docker run --rm --mount type=bind,src=$LOG_DIR,dst=/logs --network host --name sender$i --hostname sender$i middleware $CMD &
    sleep 0.3
done

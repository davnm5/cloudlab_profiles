#!/bin/bash

if [ "$#" != 1 ] | [ "$1" != "start" ] && [ "$1" != "clean" ]; then
    echo "Illegal parameters"
    exit 1
fi

if [ "$1" == "start" ];then
    echo "STARTING..."
    kubectl apply -f kube-safe-scheduler/yamlfiles/service-account.yaml
    kubectl apply -f kube-safe-scheduler/yamlfiles/extender.safe.yaml
    kubectl apply -f kube-safe-scheduler/node-annotator/usage/node-annotator.yaml
else
    echo "CLEANING..."
    kubectl delete -f kube-safe-scheduler/yamlfiles/extender.safe.yaml
    kubectl delete -f kube-safe-scheduler/node-annotator/usage/node-annotator.yaml
fi

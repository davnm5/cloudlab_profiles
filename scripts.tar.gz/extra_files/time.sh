#!/bin/bash
x1=1
x2=1
if [ "$#" != 1 ]; then
    echo "Illegal parameters"
    exit 1
fi
start=`date +%s%3N`
kubectl apply -f dp.yaml
kubectl scale deployment/deployment-xapps --replicas=$1
while :
do
xapp=$(echo "$(kubectl get deployments | grep deployment-xapps | awk '{print $4}')")
sender=$(echo "$(kubectl get deployments | grep deployment-sender | awk '{print $4}')")
: ' echo "Status xapps: ${xapp}"
echo "Status sender: ${sender}"
if [ $xapp == $1 ] && [ $x1 == 1 ]; then
end_xapps=`date +%s%3N`
echo xapps: `expr $end_xapps - $start` >> time.txt
x1=0
fi
if [ $sender == 1 ] && [ $x2 == 1 ]; then
end_sender=`date +%s%3N`
echo sender: `expr $end_sender - $start` >> time.txt
x2=0
fi '
if [ $sender == 1 ] && [ $xapp == $1 ]; then
end_total=`date +%s%3N`
echo total: `expr $end_total - $start` >> time.txt
break
fi
done
